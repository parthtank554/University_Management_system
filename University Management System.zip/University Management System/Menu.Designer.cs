﻿
namespace University_Management_System
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_logout = new Guna.UI.WinForms.GunaButton();
            this.btn_campus = new Guna.UI.WinForms.GunaButton();
            this.btn_salary = new Guna.UI.WinForms.GunaButton();
            this.btn_fees = new Guna.UI.WinForms.GunaButton();
            this.btn_course = new Guna.UI.WinForms.GunaButton();
            this.btn_faculty = new Guna.UI.WinForms.GunaButton();
            this.btn_department = new Guna.UI.WinForms.GunaButton();
            this.Btn_student = new Guna.UI.WinForms.GunaButton();
            this.Btn_Home = new Guna.UI.WinForms.GunaButton();
            this.lblcampus = new Guna.UI.WinForms.GunaLabel();
            this.lblsalary = new Guna.UI.WinForms.GunaLabel();
            this.lblfees = new Guna.UI.WinForms.GunaLabel();
            this.lblcourse = new Guna.UI.WinForms.GunaLabel();
            this.lblfaculty = new Guna.UI.WinForms.GunaLabel();
            this.lblstudent = new Guna.UI.WinForms.GunaLabel();
            this.lblhome = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.menu_exit = new Guna.UI.WinForms.GunaButton();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_logout
            // 
            this.btn_logout.AnimationHoverSpeed = 0.07F;
            this.btn_logout.AnimationSpeed = 0.03F;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.BaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.BorderColor = System.Drawing.Color.Black;
            this.btn_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Black;
            this.btn_logout.Image = null;
            this.btn_logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_logout.Location = new System.Drawing.Point(111, 740);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_logout.OnHoverImage = null;
            this.btn_logout.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_logout.Radius = 8;
            this.btn_logout.Size = new System.Drawing.Size(160, 42);
            this.btn_logout.TabIndex = 46;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_campus
            // 
            this.btn_campus.AnimationHoverSpeed = 0.07F;
            this.btn_campus.AnimationSpeed = 0.03F;
            this.btn_campus.BackColor = System.Drawing.Color.Transparent;
            this.btn_campus.BaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.BorderColor = System.Drawing.Color.Black;
            this.btn_campus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_campus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_campus.ForeColor = System.Drawing.Color.Black;
            this.btn_campus.Image = null;
            this.btn_campus.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_campus.Location = new System.Drawing.Point(111, 663);
            this.btn_campus.Name = "btn_campus";
            this.btn_campus.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_campus.OnHoverImage = null;
            this.btn_campus.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_campus.Radius = 8;
            this.btn_campus.Size = new System.Drawing.Size(160, 42);
            this.btn_campus.TabIndex = 45;
            this.btn_campus.Text = "Campus";
            this.btn_campus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.Click += new System.EventHandler(this.btn_campus_Click);
            // 
            // btn_salary
            // 
            this.btn_salary.AnimationHoverSpeed = 0.07F;
            this.btn_salary.AnimationSpeed = 0.03F;
            this.btn_salary.BackColor = System.Drawing.Color.Transparent;
            this.btn_salary.BaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.BorderColor = System.Drawing.Color.Black;
            this.btn_salary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary.ForeColor = System.Drawing.Color.Black;
            this.btn_salary.Image = null;
            this.btn_salary.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_salary.Location = new System.Drawing.Point(111, 587);
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_salary.OnHoverImage = null;
            this.btn_salary.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_salary.Radius = 8;
            this.btn_salary.Size = new System.Drawing.Size(160, 42);
            this.btn_salary.TabIndex = 44;
            this.btn_salary.Text = "Salary";
            this.btn_salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_fees
            // 
            this.btn_fees.AnimationHoverSpeed = 0.07F;
            this.btn_fees.AnimationSpeed = 0.03F;
            this.btn_fees.BackColor = System.Drawing.Color.Transparent;
            this.btn_fees.BaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.BorderColor = System.Drawing.Color.Black;
            this.btn_fees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fees.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fees.ForeColor = System.Drawing.Color.Black;
            this.btn_fees.Image = null;
            this.btn_fees.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_fees.Location = new System.Drawing.Point(111, 501);
            this.btn_fees.Name = "btn_fees";
            this.btn_fees.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_fees.OnHoverImage = null;
            this.btn_fees.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_fees.Radius = 8;
            this.btn_fees.Size = new System.Drawing.Size(160, 42);
            this.btn_fees.TabIndex = 43;
            this.btn_fees.Text = "Fees";
            this.btn_fees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.Click += new System.EventHandler(this.btn_fees_Click);
            // 
            // btn_course
            // 
            this.btn_course.AnimationHoverSpeed = 0.07F;
            this.btn_course.AnimationSpeed = 0.03F;
            this.btn_course.BackColor = System.Drawing.Color.Transparent;
            this.btn_course.BaseColor = System.Drawing.Color.Transparent;
            this.btn_course.BorderColor = System.Drawing.Color.Black;
            this.btn_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_course.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_course.ForeColor = System.Drawing.Color.Black;
            this.btn_course.Image = null;
            this.btn_course.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_course.Location = new System.Drawing.Point(123, 426);
            this.btn_course.Name = "btn_course";
            this.btn_course.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_course.OnHoverImage = null;
            this.btn_course.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_course.Radius = 8;
            this.btn_course.Size = new System.Drawing.Size(160, 42);
            this.btn_course.TabIndex = 42;
            this.btn_course.Text = "Courses";
            this.btn_course.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.Click += new System.EventHandler(this.btn_course_Click);
            // 
            // btn_faculty
            // 
            this.btn_faculty.AnimationHoverSpeed = 0.07F;
            this.btn_faculty.AnimationSpeed = 0.03F;
            this.btn_faculty.BackColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BorderColor = System.Drawing.Color.Black;
            this.btn_faculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_faculty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_faculty.ForeColor = System.Drawing.Color.Black;
            this.btn_faculty.Image = null;
            this.btn_faculty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_faculty.Location = new System.Drawing.Point(123, 344);
            this.btn_faculty.Name = "btn_faculty";
            this.btn_faculty.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_faculty.OnHoverImage = null;
            this.btn_faculty.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_faculty.Radius = 8;
            this.btn_faculty.Size = new System.Drawing.Size(160, 42);
            this.btn_faculty.TabIndex = 41;
            this.btn_faculty.Text = "Faculty";
            this.btn_faculty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.Click += new System.EventHandler(this.btn_faculty_Click);
            // 
            // btn_department
            // 
            this.btn_department.AnimationHoverSpeed = 0.07F;
            this.btn_department.AnimationSpeed = 0.03F;
            this.btn_department.BackColor = System.Drawing.Color.Transparent;
            this.btn_department.BaseColor = System.Drawing.Color.Transparent;
            this.btn_department.BorderColor = System.Drawing.Color.Black;
            this.btn_department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_department.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_department.ForeColor = System.Drawing.Color.Black;
            this.btn_department.Image = null;
            this.btn_department.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_department.Location = new System.Drawing.Point(123, 268);
            this.btn_department.Name = "btn_department";
            this.btn_department.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_department.OnHoverImage = null;
            this.btn_department.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_department.Radius = 8;
            this.btn_department.Size = new System.Drawing.Size(160, 42);
            this.btn_department.TabIndex = 40;
            this.btn_department.Text = "Department";
            this.btn_department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.Click += new System.EventHandler(this.btn_department_Click);
            // 
            // Btn_student
            // 
            this.Btn_student.AnimationHoverSpeed = 0.07F;
            this.Btn_student.AnimationSpeed = 0.03F;
            this.Btn_student.BackColor = System.Drawing.Color.Transparent;
            this.Btn_student.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.BorderColor = System.Drawing.Color.Black;
            this.Btn_student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_student.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_student.ForeColor = System.Drawing.Color.Black;
            this.Btn_student.Image = null;
            this.Btn_student.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_student.Location = new System.Drawing.Point(111, 182);
            this.Btn_student.Name = "Btn_student";
            this.Btn_student.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_student.OnHoverImage = null;
            this.Btn_student.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_student.Radius = 8;
            this.Btn_student.Size = new System.Drawing.Size(160, 42);
            this.Btn_student.TabIndex = 39;
            this.Btn_student.Text = "Student";
            this.Btn_student.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.Click += new System.EventHandler(this.Btn_student_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.AnimationHoverSpeed = 0.07F;
            this.Btn_Home.AnimationSpeed = 0.03F;
            this.Btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BorderColor = System.Drawing.Color.Black;
            this.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Home.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Home.ForeColor = System.Drawing.Color.Black;
            this.Btn_Home.Image = null;
            this.Btn_Home.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_Home.Location = new System.Drawing.Point(111, 115);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_Home.OnHoverImage = null;
            this.Btn_Home.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_Home.Radius = 8;
            this.Btn_Home.Size = new System.Drawing.Size(160, 42);
            this.Btn_Home.TabIndex = 38;
            this.Btn_Home.Text = "Home";
            this.Btn_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // lblcampus
            // 
            this.lblcampus.AutoSize = true;
            this.lblcampus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcampus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcampus.Location = new System.Drawing.Point(131, 668);
            this.lblcampus.Name = "lblcampus";
            this.lblcampus.Size = new System.Drawing.Size(108, 29);
            this.lblcampus.TabIndex = 18;
            this.lblcampus.Text = "Campus";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(131, 587);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(86, 29);
            this.lblsalary.TabIndex = 17;
            this.lblsalary.Text = "Salary";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfees.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfees.Location = new System.Drawing.Point(131, 504);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(72, 29);
            this.lblfees.TabIndex = 16;
            this.lblfees.Text = "Fees";
            this.lblfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourse.Location = new System.Drawing.Point(131, 426);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(97, 29);
            this.lblcourse.TabIndex = 15;
            this.lblcourse.Text = "Course";
            // 
            // lblfaculty
            // 
            this.lblfaculty.AutoSize = true;
            this.lblfaculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfaculty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfaculty.Location = new System.Drawing.Point(131, 346);
            this.lblfaculty.Name = "lblfaculty";
            this.lblfaculty.Size = new System.Drawing.Size(96, 29);
            this.lblfaculty.TabIndex = 14;
            this.lblfaculty.Text = "Faculty";
            // 
            // lblstudent
            // 
            this.lblstudent.AutoSize = true;
            this.lblstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudent.Location = new System.Drawing.Point(131, 191);
            this.lblstudent.Name = "lblstudent";
            this.lblstudent.Size = new System.Drawing.Size(102, 29);
            this.lblstudent.TabIndex = 12;
            this.lblstudent.Text = "Student";
            // 
            // lblhome
            // 
            this.lblhome.AutoSize = true;
            this.lblhome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhome.Location = new System.Drawing.Point(131, 118);
            this.lblhome.Name = "lblhome";
            this.lblhome.Size = new System.Drawing.Size(82, 29);
            this.lblhome.TabIndex = 11;
            this.lblhome.Text = "Home";
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.gunaPanel1.Controls.Add(this.btn_logout);
            this.gunaPanel1.Controls.Add(this.btn_campus);
            this.gunaPanel1.Controls.Add(this.btn_salary);
            this.gunaPanel1.Controls.Add(this.btn_fees);
            this.gunaPanel1.Controls.Add(this.btn_course);
            this.gunaPanel1.Controls.Add(this.btn_faculty);
            this.gunaPanel1.Controls.Add(this.btn_department);
            this.gunaPanel1.Controls.Add(this.Btn_student);
            this.gunaPanel1.Controls.Add(this.Btn_Home);
            this.gunaPanel1.Controls.Add(this.lblcampus);
            this.gunaPanel1.Controls.Add(this.lblsalary);
            this.gunaPanel1.Controls.Add(this.lblfees);
            this.gunaPanel1.Controls.Add(this.lblcourse);
            this.gunaPanel1.Controls.Add(this.lblfaculty);
            this.gunaPanel1.Controls.Add(this.lblstudent);
            this.gunaPanel1.Controls.Add(this.lblhome);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox8);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox7);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel1.Location = new System.Drawing.Point(3, -3);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(301, 792);
            this.gunaPanel1.TabIndex = 2;
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Image = global::University_Management_System.Properties.Resources.logout;
            this.gunaPictureBox10.Location = new System.Drawing.Point(44, 734);
            this.gunaPictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 9;
            this.gunaPictureBox10.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::University_Management_System.Properties.Resources.campus;
            this.gunaPictureBox9.Location = new System.Drawing.Point(44, 653);
            this.gunaPictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 8;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::University_Management_System.Properties.Resources.salary;
            this.gunaPictureBox8.Location = new System.Drawing.Point(44, 578);
            this.gunaPictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 7;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::University_Management_System.Properties.Resources.fees;
            this.gunaPictureBox7.Location = new System.Drawing.Point(44, 495);
            this.gunaPictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 6;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::University_Management_System.Properties.Resources.course;
            this.gunaPictureBox6.Location = new System.Drawing.Point(44, 417);
            this.gunaPictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 5;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::University_Management_System.Properties.Resources.faculty;
            this.gunaPictureBox5.Location = new System.Drawing.Point(44, 334);
            this.gunaPictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::University_Management_System.Properties.Resources.Department;
            this.gunaPictureBox4.Location = new System.Drawing.Point(44, 258);
            this.gunaPictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.student;
            this.gunaPictureBox3.Location = new System.Drawing.Point(44, 181);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.home;
            this.gunaPictureBox2.Location = new System.Drawing.Point(44, 109);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.university;
            this.gunaPictureBox1.Location = new System.Drawing.Point(123, 24);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(73, 60);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.White;
            this.gunaPanel2.Controls.Add(this.menu_exit);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Location = new System.Drawing.Point(295, -3);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(936, 792);
            this.gunaPanel2.TabIndex = 21;
            // 
            // menu_exit
            // 
            this.menu_exit.AnimationHoverSpeed = 0.07F;
            this.menu_exit.AnimationSpeed = 0.03F;
            this.menu_exit.BaseColor = System.Drawing.Color.Transparent;
            this.menu_exit.BorderColor = System.Drawing.Color.Black;
            this.menu_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menu_exit.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_exit.ForeColor = System.Drawing.Color.Red;
            this.menu_exit.Image = null;
            this.menu_exit.ImageSize = new System.Drawing.Size(20, 20);
            this.menu_exit.Location = new System.Drawing.Point(858, 36);
            this.menu_exit.Name = "menu_exit";
            this.menu_exit.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.menu_exit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.menu_exit.OnHoverForeColor = System.Drawing.Color.Red;
            this.menu_exit.OnHoverImage = null;
            this.menu_exit.OnPressedColor = System.Drawing.Color.Black;
            this.menu_exit.Size = new System.Drawing.Size(45, 42);
            this.menu_exit.TabIndex = 23;
            this.menu_exit.Text = "X";
            this.menu_exit.Click += new System.EventHandler(this.menu_exit_Click);
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Viner Hand ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(274, 89);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(312, 45);
            this.gunaLabel2.TabIndex = 25;
            this.gunaLabel2.Text = "Discovering Knowledge";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(253, 36);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(343, 45);
            this.gunaLabel1.TabIndex = 24;
            this.gunaLabel1.Text = "RK UNIVERSITY";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 787);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaButton btn_logout;
        private Guna.UI.WinForms.GunaButton btn_campus;
        private Guna.UI.WinForms.GunaButton btn_salary;
        private Guna.UI.WinForms.GunaButton btn_fees;
        private Guna.UI.WinForms.GunaButton btn_course;
        private Guna.UI.WinForms.GunaButton btn_faculty;
        private Guna.UI.WinForms.GunaButton btn_department;
        private Guna.UI.WinForms.GunaButton Btn_student;
        private Guna.UI.WinForms.GunaButton Btn_Home;
        private Guna.UI.WinForms.GunaLabel lblcampus;
        private Guna.UI.WinForms.GunaLabel lblsalary;
        private Guna.UI.WinForms.GunaLabel lblfees;
        private Guna.UI.WinForms.GunaLabel lblcourse;
        private Guna.UI.WinForms.GunaLabel lblfaculty;
        private Guna.UI.WinForms.GunaLabel lblstudent;
        private Guna.UI.WinForms.GunaLabel lblhome;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaButton menu_exit;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
    }
}