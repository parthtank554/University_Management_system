﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Fees : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        public Fees()
        {
            InitializeComponent();
            Display();
            GetStudentId();
        }
        private void GetStudentId()
        {
            con.Open();
            cmd = new SqlCommand("Select StId from Student_Tbl", con);
            SqlDataReader Reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Columns.Add("StId", typeof(int));
            data.Load(Reader);
            StIdCb.ValueMember = "StId";
            StIdCb.DataSource = data;
            con.Close();
        }
        private void GetStudentInfo()
        {
            con.Open();
            string Query = "Select * from Student_Tbl where StId = " + StIdCb.SelectedValue.ToString() + " ";
            cmd = new SqlCommand(Query, con);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                StNameTb.Text = dataRow["Name"].ToString();
                StDeptTb.Text = dataRow["Department"].ToString();
            }
            con.Close();
        }
        private void Display()
        {
            DataTable data1 = new DataTable();
            con.Open();
            SqlDataAdapter adapter1 = new SqlDataAdapter("select * from FeesTbl", con);
            adapter1.Fill(data1);
            Fees_DGV.DataSource = data1;
            con.Close();
        }
        private void Reset()
        {
            StNameTb.Text = "";
            AmountTb.Text = "";
            StDeptTb.Text = "";
            StIdCb.SelectedIndex = -1;
            SemesterCb.SelectedIndex = -1;
        }

        int Key = 0;
        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void fee_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fee_btn_pay_Click(object sender, EventArgs e)
        {
            if (StNameTb.Text == "" || StIdCb.SelectedIndex == -1 || StDeptTb.Text == "" || AmountTb.Text == "" || SemesterCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {

                con.Open();
                cmd = new SqlCommand("Insert into FeesTbl(StId,StName,StDept,Amount,Semester,PayDate)values(@SId,@SN,@SDep,@Amount,@Sem,@Date)", con);
                cmd.Parameters.AddWithValue("@SId", StIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@SN", StNameTb.Text);
                cmd.Parameters.AddWithValue("@SDep", StDeptTb.Text);
                cmd.Parameters.AddWithValue("@Amount", AmountTb.Text);
                cmd.Parameters.AddWithValue("@Sem", SemesterCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Date", DateTime.Today.Date);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Fee Paid");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void StIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetStudentInfo();
        }

        private void fee_btn_reset_Click(object sender, EventArgs e)
        {
            if (StNameTb.Text == "" || StIdCb.SelectedIndex == -1 || StDeptTb.Text == "" || AmountTb.Text == "" || SemesterCb.SelectedIndex == -1)
            {
                MessageBox.Show("Select a Student...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from FeesTbl where Fee_Id=@FKey", con);
                cmd.Parameters.AddWithValue("@FKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Record Deleted");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void Fees_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            StIdCb.SelectedValue = Fees_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            StNameTb.Text = Fees_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            StDeptTb.Text = Fees_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            SemesterCb.SelectedItem = Fees_DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            AmountTb.Text = Fees_DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            if (StNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(Fees_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }
    }
}
