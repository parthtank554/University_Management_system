﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace University_Management_System
{
    public partial class Signup : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand user_cmd;
        public Signup()
        {
            InitializeComponent();
        }

        private void createaccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Signupbtn_Click(object sender, EventArgs e)
        {
            if(PassTb.Text == CpassTb.Text)
            {
                if (UserName.Text == "" || PassTb.Text == "" || CpassTb.Text == "")
                {
                    MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    try
                    {
                        insert();
                    }
                    catch(Exception Ex)
                    {
                        MessageBox.Show(Ex.Message, "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("Password Do Not Matched...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        void insert()
        {
            con.Open();
            user_cmd = new SqlCommand("insert into User_Tbl(User_Name, Password) values('" + UserName.Text + "', '" + PassTb.Text + "')", con);
            user_cmd.ExecuteNonQuery();

            DialogBox Db = new DialogBox("Account Created");
            Db.ShowDialog();
            con.Close();

            Login lg = new Login();
            this.Hide();
            lg.Show();
        }
        private void ShowPass_CheckedChanged(object sender, EventArgs e)
        {
        }
    }
}
