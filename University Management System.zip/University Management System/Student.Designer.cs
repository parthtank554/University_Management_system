﻿
namespace University_Management_System
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_logout = new Guna.UI.WinForms.GunaButton();
            this.btn_campus = new Guna.UI.WinForms.GunaButton();
            this.btn_salary = new Guna.UI.WinForms.GunaButton();
            this.btn_fees = new Guna.UI.WinForms.GunaButton();
            this.btn_course = new Guna.UI.WinForms.GunaButton();
            this.btn_faculty = new Guna.UI.WinForms.GunaButton();
            this.btn_department = new Guna.UI.WinForms.GunaButton();
            this.Btn_student = new Guna.UI.WinForms.GunaButton();
            this.Btn_Home = new Guna.UI.WinForms.GunaButton();
            this.lblcampus = new Guna.UI.WinForms.GunaLabel();
            this.lblsalary = new Guna.UI.WinForms.GunaLabel();
            this.lblfees = new Guna.UI.WinForms.GunaLabel();
            this.lblcourse = new Guna.UI.WinForms.GunaLabel();
            this.lblfaculty = new Guna.UI.WinForms.GunaLabel();
            this.lblstudent = new Guna.UI.WinForms.GunaLabel();
            this.lblhome = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.StNameTb = new Guna.UI.WinForms.GunaTextBox();
            this.St_DeptTb = new Guna.UI.WinForms.GunaTextBox();
            this.St_PhoneTb = new Guna.UI.WinForms.GunaTextBox();
            this.StDOBdt = new System.Windows.Forms.DateTimePicker();
            this.student_btn_save = new Guna.UI.WinForms.GunaButton();
            this.student_btn_edit = new Guna.UI.WinForms.GunaButton();
            this.student_btn_delete = new Guna.UI.WinForms.GunaButton();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.Student_DGV = new Guna.UI.WinForms.GunaDataGridView();
            this.std_exit = new Guna.UI.WinForms.GunaButton();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.StAddressTb = new Guna.UI.WinForms.GunaTextBox();
            this.StGenderCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.St_DeptIdCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.St_SemesterCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Student_DGV)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_logout
            // 
            this.btn_logout.AnimationHoverSpeed = 0.07F;
            this.btn_logout.AnimationSpeed = 0.03F;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.BaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.BorderColor = System.Drawing.Color.Black;
            this.btn_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_logout.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Black;
            this.btn_logout.Image = null;
            this.btn_logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_logout.Location = new System.Drawing.Point(111, 729);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_logout.OnHoverImage = null;
            this.btn_logout.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_logout.Radius = 8;
            this.btn_logout.Size = new System.Drawing.Size(160, 42);
            this.btn_logout.TabIndex = 46;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_campus
            // 
            this.btn_campus.AnimationHoverSpeed = 0.07F;
            this.btn_campus.AnimationSpeed = 0.03F;
            this.btn_campus.BackColor = System.Drawing.Color.Transparent;
            this.btn_campus.BaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.BorderColor = System.Drawing.Color.Black;
            this.btn_campus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_campus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_campus.ForeColor = System.Drawing.Color.Black;
            this.btn_campus.Image = null;
            this.btn_campus.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_campus.Location = new System.Drawing.Point(111, 652);
            this.btn_campus.Name = "btn_campus";
            this.btn_campus.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_campus.OnHoverImage = null;
            this.btn_campus.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_campus.Radius = 8;
            this.btn_campus.Size = new System.Drawing.Size(160, 42);
            this.btn_campus.TabIndex = 45;
            this.btn_campus.Text = "Campus";
            this.btn_campus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.Click += new System.EventHandler(this.btn_campus_Click);
            // 
            // btn_salary
            // 
            this.btn_salary.AnimationHoverSpeed = 0.07F;
            this.btn_salary.AnimationSpeed = 0.03F;
            this.btn_salary.BackColor = System.Drawing.Color.Transparent;
            this.btn_salary.BaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.BorderColor = System.Drawing.Color.Black;
            this.btn_salary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_salary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary.ForeColor = System.Drawing.Color.Black;
            this.btn_salary.Image = null;
            this.btn_salary.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_salary.Location = new System.Drawing.Point(111, 576);
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_salary.OnHoverImage = null;
            this.btn_salary.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_salary.Radius = 8;
            this.btn_salary.Size = new System.Drawing.Size(160, 42);
            this.btn_salary.TabIndex = 44;
            this.btn_salary.Text = "Salary";
            this.btn_salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_fees
            // 
            this.btn_fees.AnimationHoverSpeed = 0.07F;
            this.btn_fees.AnimationSpeed = 0.03F;
            this.btn_fees.BackColor = System.Drawing.Color.Transparent;
            this.btn_fees.BaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.BorderColor = System.Drawing.Color.Black;
            this.btn_fees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fees.ForeColor = System.Drawing.Color.Black;
            this.btn_fees.Image = null;
            this.btn_fees.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_fees.Location = new System.Drawing.Point(111, 490);
            this.btn_fees.Name = "btn_fees";
            this.btn_fees.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_fees.OnHoverImage = null;
            this.btn_fees.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_fees.Radius = 8;
            this.btn_fees.Size = new System.Drawing.Size(160, 42);
            this.btn_fees.TabIndex = 43;
            this.btn_fees.Text = "Fees";
            this.btn_fees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.Click += new System.EventHandler(this.btn_fees_Click);
            // 
            // btn_course
            // 
            this.btn_course.AnimationHoverSpeed = 0.07F;
            this.btn_course.AnimationSpeed = 0.03F;
            this.btn_course.BackColor = System.Drawing.Color.Transparent;
            this.btn_course.BaseColor = System.Drawing.Color.Transparent;
            this.btn_course.BorderColor = System.Drawing.Color.Black;
            this.btn_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_course.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_course.ForeColor = System.Drawing.Color.Black;
            this.btn_course.Image = null;
            this.btn_course.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_course.Location = new System.Drawing.Point(123, 415);
            this.btn_course.Name = "btn_course";
            this.btn_course.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_course.OnHoverImage = null;
            this.btn_course.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_course.Radius = 8;
            this.btn_course.Size = new System.Drawing.Size(160, 42);
            this.btn_course.TabIndex = 42;
            this.btn_course.Text = "Courses";
            this.btn_course.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.Click += new System.EventHandler(this.btn_course_Click);
            // 
            // btn_faculty
            // 
            this.btn_faculty.AnimationHoverSpeed = 0.07F;
            this.btn_faculty.AnimationSpeed = 0.03F;
            this.btn_faculty.BackColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BorderColor = System.Drawing.Color.Black;
            this.btn_faculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_faculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_faculty.ForeColor = System.Drawing.Color.Black;
            this.btn_faculty.Image = null;
            this.btn_faculty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_faculty.Location = new System.Drawing.Point(123, 333);
            this.btn_faculty.Name = "btn_faculty";
            this.btn_faculty.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_faculty.OnHoverImage = null;
            this.btn_faculty.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_faculty.Radius = 8;
            this.btn_faculty.Size = new System.Drawing.Size(160, 42);
            this.btn_faculty.TabIndex = 41;
            this.btn_faculty.Text = "Faculty";
            this.btn_faculty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.Click += new System.EventHandler(this.btn_faculty_Click);
            // 
            // btn_department
            // 
            this.btn_department.AnimationHoverSpeed = 0.07F;
            this.btn_department.AnimationSpeed = 0.03F;
            this.btn_department.BackColor = System.Drawing.Color.Transparent;
            this.btn_department.BaseColor = System.Drawing.Color.Transparent;
            this.btn_department.BorderColor = System.Drawing.Color.Black;
            this.btn_department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_department.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_department.ForeColor = System.Drawing.Color.Black;
            this.btn_department.Image = null;
            this.btn_department.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_department.Location = new System.Drawing.Point(123, 257);
            this.btn_department.Name = "btn_department";
            this.btn_department.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_department.OnHoverImage = null;
            this.btn_department.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_department.Radius = 8;
            this.btn_department.Size = new System.Drawing.Size(160, 42);
            this.btn_department.TabIndex = 40;
            this.btn_department.Text = "Department";
            this.btn_department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.Click += new System.EventHandler(this.btn_department_Click);
            // 
            // Btn_student
            // 
            this.Btn_student.AnimationHoverSpeed = 0.07F;
            this.Btn_student.AnimationSpeed = 0.03F;
            this.Btn_student.BackColor = System.Drawing.Color.Transparent;
            this.Btn_student.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.BorderColor = System.Drawing.Color.Black;
            this.Btn_student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_student.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_student.ForeColor = System.Drawing.Color.Black;
            this.Btn_student.Image = null;
            this.Btn_student.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_student.Location = new System.Drawing.Point(111, 171);
            this.Btn_student.Name = "Btn_student";
            this.Btn_student.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_student.OnHoverImage = null;
            this.Btn_student.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_student.Radius = 8;
            this.Btn_student.Size = new System.Drawing.Size(160, 42);
            this.Btn_student.TabIndex = 39;
            this.Btn_student.Text = "Student";
            this.Btn_student.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.Click += new System.EventHandler(this.Btn_student_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.AnimationHoverSpeed = 0.07F;
            this.Btn_Home.AnimationSpeed = 0.03F;
            this.Btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BorderColor = System.Drawing.Color.Black;
            this.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Home.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Home.ForeColor = System.Drawing.Color.Black;
            this.Btn_Home.Image = null;
            this.Btn_Home.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_Home.Location = new System.Drawing.Point(111, 104);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_Home.OnHoverImage = null;
            this.Btn_Home.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_Home.Radius = 8;
            this.Btn_Home.Size = new System.Drawing.Size(160, 42);
            this.Btn_Home.TabIndex = 38;
            this.Btn_Home.Text = "Home";
            this.Btn_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // lblcampus
            // 
            this.lblcampus.AutoSize = true;
            this.lblcampus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcampus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcampus.Location = new System.Drawing.Point(131, 657);
            this.lblcampus.Name = "lblcampus";
            this.lblcampus.Size = new System.Drawing.Size(95, 26);
            this.lblcampus.TabIndex = 18;
            this.lblcampus.Text = "Campus";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblsalary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(131, 576);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(79, 26);
            this.lblsalary.TabIndex = 17;
            this.lblsalary.Text = "Salary";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfees.Location = new System.Drawing.Point(131, 493);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(58, 26);
            this.lblfees.TabIndex = 16;
            this.lblfees.Text = "Fees";
            this.lblfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcourse.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourse.Location = new System.Drawing.Point(131, 415);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(85, 26);
            this.lblcourse.TabIndex = 15;
            this.lblcourse.Text = "Course";
            // 
            // lblfaculty
            // 
            this.lblfaculty.AutoSize = true;
            this.lblfaculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfaculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfaculty.Location = new System.Drawing.Point(131, 335);
            this.lblfaculty.Name = "lblfaculty";
            this.lblfaculty.Size = new System.Drawing.Size(90, 26);
            this.lblfaculty.TabIndex = 14;
            this.lblfaculty.Text = "Faculty";
            // 
            // lblstudent
            // 
            this.lblstudent.AutoSize = true;
            this.lblstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblstudent.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudent.Location = new System.Drawing.Point(131, 180);
            this.lblstudent.Name = "lblstudent";
            this.lblstudent.Size = new System.Drawing.Size(91, 26);
            this.lblstudent.TabIndex = 12;
            this.lblstudent.Text = "Student";
            // 
            // lblhome
            // 
            this.lblhome.AutoSize = true;
            this.lblhome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblhome.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhome.Location = new System.Drawing.Point(131, 107);
            this.lblhome.Name = "lblhome";
            this.lblhome.Size = new System.Drawing.Size(73, 26);
            this.lblhome.TabIndex = 11;
            this.lblhome.Text = "Home";
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Image = global::University_Management_System.Properties.Resources.logout;
            this.gunaPictureBox10.Location = new System.Drawing.Point(44, 723);
            this.gunaPictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 9;
            this.gunaPictureBox10.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::University_Management_System.Properties.Resources.campus;
            this.gunaPictureBox9.Location = new System.Drawing.Point(44, 642);
            this.gunaPictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 8;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::University_Management_System.Properties.Resources.salary;
            this.gunaPictureBox8.Location = new System.Drawing.Point(44, 567);
            this.gunaPictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 7;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::University_Management_System.Properties.Resources.fees;
            this.gunaPictureBox7.Location = new System.Drawing.Point(44, 484);
            this.gunaPictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 6;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::University_Management_System.Properties.Resources.course;
            this.gunaPictureBox6.Location = new System.Drawing.Point(44, 406);
            this.gunaPictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 5;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::University_Management_System.Properties.Resources.faculty;
            this.gunaPictureBox5.Location = new System.Drawing.Point(44, 323);
            this.gunaPictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::University_Management_System.Properties.Resources.Department;
            this.gunaPictureBox4.Location = new System.Drawing.Point(44, 247);
            this.gunaPictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.student;
            this.gunaPictureBox3.Location = new System.Drawing.Point(44, 170);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.home;
            this.gunaPictureBox2.Location = new System.Drawing.Point(44, 98);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.university;
            this.gunaPictureBox1.Location = new System.Drawing.Point(123, 13);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(73, 60);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.gunaPanel1.Controls.Add(this.btn_logout);
            this.gunaPanel1.Controls.Add(this.btn_campus);
            this.gunaPanel1.Controls.Add(this.btn_salary);
            this.gunaPanel1.Controls.Add(this.btn_fees);
            this.gunaPanel1.Controls.Add(this.btn_course);
            this.gunaPanel1.Controls.Add(this.btn_faculty);
            this.gunaPanel1.Controls.Add(this.btn_department);
            this.gunaPanel1.Controls.Add(this.Btn_student);
            this.gunaPanel1.Controls.Add(this.Btn_Home);
            this.gunaPanel1.Controls.Add(this.lblcampus);
            this.gunaPanel1.Controls.Add(this.lblsalary);
            this.gunaPanel1.Controls.Add(this.lblfees);
            this.gunaPanel1.Controls.Add(this.lblcourse);
            this.gunaPanel1.Controls.Add(this.lblfaculty);
            this.gunaPanel1.Controls.Add(this.lblstudent);
            this.gunaPanel1.Controls.Add(this.lblhome);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox8);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox7);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel1.Location = new System.Drawing.Point(1, -7);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(309, 891);
            this.gunaPanel1.TabIndex = 1;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(235, 16);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(343, 45);
            this.gunaLabel1.TabIndex = 68;
            this.gunaLabel1.Text = "RK UNIVERSITY";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Viner Hand ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(256, 69);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(312, 45);
            this.gunaLabel2.TabIndex = 69;
            this.gunaLabel2.Text = "Discovering Knowledge";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel6.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(43, 153);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(148, 28);
            this.gunaLabel6.TabIndex = 70;
            this.gunaLabel6.Text = "Stud Name";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel3.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(546, 270);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(151, 28);
            this.gunaLabel3.TabIndex = 71;
            this.gunaLabel3.Text = "Dept Name";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel4.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(43, 270);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(183, 28);
            this.gunaLabel4.TabIndex = 72;
            this.gunaLabel4.Text = "Phon Number";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel5.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(553, 153);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(176, 28);
            this.gunaLabel5.TabIndex = 73;
            this.gunaLabel5.Text = "Date Of Birth";
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel7.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(311, 153);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(103, 28);
            this.gunaLabel7.TabIndex = 74;
            this.gunaLabel7.Text = "Gender";
            // 
            // StNameTb
            // 
            this.StNameTb.BaseColor = System.Drawing.Color.White;
            this.StNameTb.BorderColor = System.Drawing.Color.Silver;
            this.StNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StNameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.StNameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.StNameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.StNameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.StNameTb.Location = new System.Drawing.Point(49, 193);
            this.StNameTb.Margin = new System.Windows.Forms.Padding(4);
            this.StNameTb.Name = "StNameTb";
            this.StNameTb.PasswordChar = '\0';
            this.StNameTb.Radius = 5;
            this.StNameTb.Size = new System.Drawing.Size(205, 32);
            this.StNameTb.TabIndex = 75;
            // 
            // St_DeptTb
            // 
            this.St_DeptTb.BaseColor = System.Drawing.Color.White;
            this.St_DeptTb.BorderColor = System.Drawing.Color.Silver;
            this.St_DeptTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.St_DeptTb.FocusedBaseColor = System.Drawing.Color.White;
            this.St_DeptTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.St_DeptTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.St_DeptTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.St_DeptTb.Location = new System.Drawing.Point(552, 310);
            this.St_DeptTb.Margin = new System.Windows.Forms.Padding(4);
            this.St_DeptTb.Name = "St_DeptTb";
            this.St_DeptTb.PasswordChar = '\0';
            this.St_DeptTb.Radius = 5;
            this.St_DeptTb.Size = new System.Drawing.Size(205, 32);
            this.St_DeptTb.TabIndex = 76;
            // 
            // St_PhoneTb
            // 
            this.St_PhoneTb.BaseColor = System.Drawing.Color.White;
            this.St_PhoneTb.BorderColor = System.Drawing.Color.Silver;
            this.St_PhoneTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.St_PhoneTb.FocusedBaseColor = System.Drawing.Color.White;
            this.St_PhoneTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.St_PhoneTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.St_PhoneTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.St_PhoneTb.Location = new System.Drawing.Point(49, 305);
            this.St_PhoneTb.Margin = new System.Windows.Forms.Padding(4);
            this.St_PhoneTb.Name = "St_PhoneTb";
            this.St_PhoneTb.PasswordChar = '\0';
            this.St_PhoneTb.Radius = 5;
            this.St_PhoneTb.Size = new System.Drawing.Size(205, 32);
            this.St_PhoneTb.TabIndex = 77;
            // 
            // StDOBdt
            // 
            this.StDOBdt.Location = new System.Drawing.Point(559, 187);
            this.StDOBdt.Margin = new System.Windows.Forms.Padding(4);
            this.StDOBdt.Name = "StDOBdt";
            this.StDOBdt.Size = new System.Drawing.Size(205, 37);
            this.StDOBdt.TabIndex = 78;
            this.StDOBdt.Value = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            // 
            // student_btn_save
            // 
            this.student_btn_save.AnimationHoverSpeed = 0.07F;
            this.student_btn_save.AnimationSpeed = 0.03F;
            this.student_btn_save.BackColor = System.Drawing.Color.Transparent;
            this.student_btn_save.BaseColor = System.Drawing.Color.Transparent;
            this.student_btn_save.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.student_btn_save.BorderSize = 2;
            this.student_btn_save.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_btn_save.ForeColor = System.Drawing.Color.Black;
            this.student_btn_save.Image = null;
            this.student_btn_save.ImageSize = new System.Drawing.Size(20, 20);
            this.student_btn_save.Location = new System.Drawing.Point(77, 487);
            this.student_btn_save.Margin = new System.Windows.Forms.Padding(4);
            this.student_btn_save.Name = "student_btn_save";
            this.student_btn_save.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.student_btn_save.OnHoverBorderColor = System.Drawing.Color.Black;
            this.student_btn_save.OnHoverForeColor = System.Drawing.Color.White;
            this.student_btn_save.OnHoverImage = null;
            this.student_btn_save.OnPressedColor = System.Drawing.Color.Black;
            this.student_btn_save.Radius = 8;
            this.student_btn_save.Size = new System.Drawing.Size(132, 53);
            this.student_btn_save.TabIndex = 79;
            this.student_btn_save.Text = "Save";
            this.student_btn_save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.student_btn_save.Click += new System.EventHandler(this.student_btn_save_Click);
            // 
            // student_btn_edit
            // 
            this.student_btn_edit.AnimationHoverSpeed = 0.07F;
            this.student_btn_edit.AnimationSpeed = 0.03F;
            this.student_btn_edit.BackColor = System.Drawing.Color.Transparent;
            this.student_btn_edit.BaseColor = System.Drawing.Color.Transparent;
            this.student_btn_edit.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.student_btn_edit.BorderSize = 2;
            this.student_btn_edit.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_btn_edit.ForeColor = System.Drawing.Color.Black;
            this.student_btn_edit.Image = null;
            this.student_btn_edit.ImageSize = new System.Drawing.Size(20, 20);
            this.student_btn_edit.Location = new System.Drawing.Point(345, 486);
            this.student_btn_edit.Margin = new System.Windows.Forms.Padding(4);
            this.student_btn_edit.Name = "student_btn_edit";
            this.student_btn_edit.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.student_btn_edit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.student_btn_edit.OnHoverForeColor = System.Drawing.Color.White;
            this.student_btn_edit.OnHoverImage = null;
            this.student_btn_edit.OnPressedColor = System.Drawing.Color.Black;
            this.student_btn_edit.Radius = 8;
            this.student_btn_edit.Size = new System.Drawing.Size(132, 53);
            this.student_btn_edit.TabIndex = 80;
            this.student_btn_edit.Text = "Edit";
            this.student_btn_edit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.student_btn_edit.Click += new System.EventHandler(this.student_btn_edit_Click);
            // 
            // student_btn_delete
            // 
            this.student_btn_delete.AnimationHoverSpeed = 0.07F;
            this.student_btn_delete.AnimationSpeed = 0.03F;
            this.student_btn_delete.BackColor = System.Drawing.Color.Transparent;
            this.student_btn_delete.BaseColor = System.Drawing.Color.Transparent;
            this.student_btn_delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.student_btn_delete.BorderSize = 2;
            this.student_btn_delete.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_btn_delete.ForeColor = System.Drawing.Color.Black;
            this.student_btn_delete.Image = null;
            this.student_btn_delete.ImageSize = new System.Drawing.Size(20, 20);
            this.student_btn_delete.Location = new System.Drawing.Point(586, 486);
            this.student_btn_delete.Margin = new System.Windows.Forms.Padding(4);
            this.student_btn_delete.Name = "student_btn_delete";
            this.student_btn_delete.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.student_btn_delete.OnHoverBorderColor = System.Drawing.Color.Black;
            this.student_btn_delete.OnHoverForeColor = System.Drawing.Color.White;
            this.student_btn_delete.OnHoverImage = null;
            this.student_btn_delete.OnPressedColor = System.Drawing.Color.Black;
            this.student_btn_delete.Radius = 8;
            this.student_btn_delete.Size = new System.Drawing.Size(132, 53);
            this.student_btn_delete.TabIndex = 81;
            this.student_btn_delete.Text = "Delete";
            this.student_btn_delete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.student_btn_delete.Click += new System.EventHandler(this.student_btn_delete_Click);
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPanel3.Location = new System.Drawing.Point(-5, 558);
            this.gunaPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(1041, 6);
            this.gunaPanel3.TabIndex = 82;
            // 
            // Student_DGV
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.Student_DGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Student_DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Student_DGV.BackgroundColor = System.Drawing.Color.White;
            this.Student_DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Student_DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Student_DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Student_DGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Student_DGV.ColumnHeadersHeight = 4;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Student_DGV.DefaultCellStyle = dataGridViewCellStyle6;
            this.Student_DGV.EnableHeadersVisualStyles = false;
            this.Student_DGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Student_DGV.Location = new System.Drawing.Point(6, 570);
            this.Student_DGV.Margin = new System.Windows.Forms.Padding(4);
            this.Student_DGV.Name = "Student_DGV";
            this.Student_DGV.RowHeadersVisible = false;
            this.Student_DGV.RowHeadersWidth = 51;
            this.Student_DGV.RowTemplate.Height = 24;
            this.Student_DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Student_DGV.Size = new System.Drawing.Size(904, 312);
            this.Student_DGV.TabIndex = 83;
            this.Student_DGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.Student_DGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Student_DGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Student_DGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Student_DGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Student_DGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Student_DGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Student_DGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Student_DGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Student_DGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Student_DGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student_DGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Student_DGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Student_DGV.ThemeStyle.HeaderStyle.Height = 4;
            this.Student_DGV.ThemeStyle.ReadOnly = false;
            this.Student_DGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Student_DGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Student_DGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student_DGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Student_DGV.ThemeStyle.RowsStyle.Height = 24;
            this.Student_DGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Student_DGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Student_DGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Student_DGV_CellContentClick);
            // 
            // std_exit
            // 
            this.std_exit.AnimationHoverSpeed = 0.07F;
            this.std_exit.AnimationSpeed = 0.03F;
            this.std_exit.BaseColor = System.Drawing.Color.Transparent;
            this.std_exit.BorderColor = System.Drawing.Color.Black;
            this.std_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.std_exit.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.std_exit.ForeColor = System.Drawing.Color.Red;
            this.std_exit.Image = null;
            this.std_exit.ImageSize = new System.Drawing.Size(20, 20);
            this.std_exit.Location = new System.Drawing.Point(840, 16);
            this.std_exit.Name = "std_exit";
            this.std_exit.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.std_exit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.std_exit.OnHoverForeColor = System.Drawing.Color.Red;
            this.std_exit.OnHoverImage = null;
            this.std_exit.OnPressedColor = System.Drawing.Color.Black;
            this.std_exit.Size = new System.Drawing.Size(45, 42);
            this.std_exit.TabIndex = 67;
            this.std_exit.Text = "X";
            this.std_exit.Click += new System.EventHandler(this.std_exit_Click);
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel9.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.Location = new System.Drawing.Point(44, 389);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(115, 28);
            this.gunaLabel9.TabIndex = 84;
            this.gunaLabel9.Text = "Address";
            // 
            // StAddressTb
            // 
            this.StAddressTb.BaseColor = System.Drawing.Color.White;
            this.StAddressTb.BorderColor = System.Drawing.Color.Silver;
            this.StAddressTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StAddressTb.FocusedBaseColor = System.Drawing.Color.White;
            this.StAddressTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.StAddressTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.StAddressTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.StAddressTb.Location = new System.Drawing.Point(49, 425);
            this.StAddressTb.Margin = new System.Windows.Forms.Padding(4);
            this.StAddressTb.Name = "StAddressTb";
            this.StAddressTb.PasswordChar = '\0';
            this.StAddressTb.Radius = 5;
            this.StAddressTb.Size = new System.Drawing.Size(220, 45);
            this.StAddressTb.TabIndex = 85;
            // 
            // StGenderCb
            // 
            this.StGenderCb.BackColor = System.Drawing.Color.Transparent;
            this.StGenderCb.BaseColor = System.Drawing.Color.White;
            this.StGenderCb.BorderColor = System.Drawing.Color.Silver;
            this.StGenderCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.StGenderCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StGenderCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.StGenderCb.ForeColor = System.Drawing.Color.Black;
            this.StGenderCb.FormattingEnabled = true;
            this.StGenderCb.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.StGenderCb.Location = new System.Drawing.Point(317, 189);
            this.StGenderCb.Margin = new System.Windows.Forms.Padding(4);
            this.StGenderCb.Name = "StGenderCb";
            this.StGenderCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.StGenderCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.StGenderCb.Radius = 5;
            this.StGenderCb.Size = new System.Drawing.Size(205, 31);
            this.StGenderCb.TabIndex = 86;
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel10.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel10.Location = new System.Drawing.Point(305, 270);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(106, 28);
            this.gunaLabel10.TabIndex = 87;
            this.gunaLabel10.Text = "Dept Id";
            // 
            // St_DeptIdCb
            // 
            this.St_DeptIdCb.BackColor = System.Drawing.Color.Transparent;
            this.St_DeptIdCb.BaseColor = System.Drawing.Color.White;
            this.St_DeptIdCb.BorderColor = System.Drawing.Color.Silver;
            this.St_DeptIdCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.St_DeptIdCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.St_DeptIdCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.St_DeptIdCb.ForeColor = System.Drawing.Color.Black;
            this.St_DeptIdCb.FormattingEnabled = true;
            this.St_DeptIdCb.Location = new System.Drawing.Point(311, 306);
            this.St_DeptIdCb.Margin = new System.Windows.Forms.Padding(4);
            this.St_DeptIdCb.Name = "St_DeptIdCb";
            this.St_DeptIdCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.St_DeptIdCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.St_DeptIdCb.Radius = 5;
            this.St_DeptIdCb.Size = new System.Drawing.Size(205, 31);
            this.St_DeptIdCb.TabIndex = 88;
            this.St_DeptIdCb.SelectionChangeCommitted += new System.EventHandler(this.St_DeptIdCb_SelectionChangeCommitted);
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.AutoSize = true;
            this.gunaLabel11.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel11.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel11.Location = new System.Drawing.Point(305, 389);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(126, 28);
            this.gunaLabel11.TabIndex = 89;
            this.gunaLabel11.Text = "Semester";
            // 
            // St_SemesterCb
            // 
            this.St_SemesterCb.BackColor = System.Drawing.Color.Transparent;
            this.St_SemesterCb.BaseColor = System.Drawing.Color.White;
            this.St_SemesterCb.BorderColor = System.Drawing.Color.Silver;
            this.St_SemesterCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.St_SemesterCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.St_SemesterCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.St_SemesterCb.ForeColor = System.Drawing.Color.Black;
            this.St_SemesterCb.FormattingEnabled = true;
            this.St_SemesterCb.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.St_SemesterCb.Location = new System.Drawing.Point(311, 425);
            this.St_SemesterCb.Margin = new System.Windows.Forms.Padding(4);
            this.St_SemesterCb.Name = "St_SemesterCb";
            this.St_SemesterCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.St_SemesterCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.St_SemesterCb.Radius = 5;
            this.St_SemesterCb.Size = new System.Drawing.Size(205, 31);
            this.St_SemesterCb.TabIndex = 90;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.White;
            this.gunaPanel2.Controls.Add(this.St_SemesterCb);
            this.gunaPanel2.Controls.Add(this.gunaLabel11);
            this.gunaPanel2.Controls.Add(this.St_DeptIdCb);
            this.gunaPanel2.Controls.Add(this.gunaLabel10);
            this.gunaPanel2.Controls.Add(this.StGenderCb);
            this.gunaPanel2.Controls.Add(this.StAddressTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel9);
            this.gunaPanel2.Controls.Add(this.std_exit);
            this.gunaPanel2.Controls.Add(this.Student_DGV);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.student_btn_delete);
            this.gunaPanel2.Controls.Add(this.student_btn_edit);
            this.gunaPanel2.Controls.Add(this.student_btn_save);
            this.gunaPanel2.Controls.Add(this.StDOBdt);
            this.gunaPanel2.Controls.Add(this.St_PhoneTb);
            this.gunaPanel2.Controls.Add(this.St_DeptTb);
            this.gunaPanel2.Controls.Add(this.StNameTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel7);
            this.gunaPanel2.Controls.Add(this.gunaLabel5);
            this.gunaPanel2.Controls.Add(this.gunaLabel4);
            this.gunaPanel2.Controls.Add(this.gunaLabel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel6);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaPanel2.Location = new System.Drawing.Point(309, 2);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(920, 911);
            this.gunaPanel2.TabIndex = 21;
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 820);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Student";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student";
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Student_DGV)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaButton btn_logout;
        private Guna.UI.WinForms.GunaButton btn_campus;
        private Guna.UI.WinForms.GunaButton btn_salary;
        private Guna.UI.WinForms.GunaButton btn_fees;
        private Guna.UI.WinForms.GunaButton btn_course;
        private Guna.UI.WinForms.GunaButton btn_faculty;
        private Guna.UI.WinForms.GunaButton btn_department;
        private Guna.UI.WinForms.GunaButton Btn_student;
        private Guna.UI.WinForms.GunaButton Btn_Home;
        private Guna.UI.WinForms.GunaLabel lblcampus;
        private Guna.UI.WinForms.GunaLabel lblsalary;
        private Guna.UI.WinForms.GunaLabel lblfees;
        private Guna.UI.WinForms.GunaLabel lblcourse;
        private Guna.UI.WinForms.GunaLabel lblfaculty;
        private Guna.UI.WinForms.GunaLabel lblstudent;
        private Guna.UI.WinForms.GunaLabel lblhome;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaTextBox StNameTb;
        private Guna.UI.WinForms.GunaTextBox St_DeptTb;
        private Guna.UI.WinForms.GunaTextBox St_PhoneTb;
        private System.Windows.Forms.DateTimePicker StDOBdt;
        private Guna.UI.WinForms.GunaButton student_btn_save;
        private Guna.UI.WinForms.GunaButton student_btn_edit;
        private Guna.UI.WinForms.GunaButton student_btn_delete;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaDataGridView Student_DGV;
        private Guna.UI.WinForms.GunaButton std_exit;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaTextBox StAddressTb;
        private Guna.UI.WinForms.GunaComboBox StGenderCb;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaComboBox St_DeptIdCb;
        private Guna.UI.WinForms.GunaLabel gunaLabel11;
        private Guna.UI.WinForms.GunaComboBox St_SemesterCb;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
    }
}