﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace University_Management_System
{
    public partial class Salaries : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        public Salaries()
        {
            InitializeComponent();
            GetFacultyId();
            Display();
        }
        private void GetFacultyId()
        {
            con.Open();
            cmd = new SqlCommand("Select F_Id from Faculty_Tbl", con);
            SqlDataReader Reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Columns.Add("F_Id", typeof(int));
            data.Load(Reader);
            Salary_FIdCb.ValueMember = "F_Id";
            Salary_FIdCb.DataSource = data;
            con.Close();
        }
        private void GetFacultyInfo()
        {
            con.Open();
            string Query = "Select * from Faculty_Tbl where F_Id = " + Salary_FIdCb.SelectedValue.ToString() + " ";
            cmd = new SqlCommand(Query, con);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                Salary_FNameTb.Text = dataRow["Name"].ToString();
                SalDeptTb.Text = dataRow["Department"].ToString();
            }
            con.Close();
        }
        private void Display()
        {
            DataTable data = new DataTable();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("Select * from SalaryTbl", con);
            adapter.Fill(data);
            salary_datagridview.DataSource = data;
            con.Close();
        }
        private void Reset()
        {
            Salary_FIdCb.SelectedIndex = -1;
            Salary_FNameTb.Text = "";
            SalDeptTb.Text = "";
            Sal_AmountTb.Text = "";
        }
        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }
        private void salary_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void salary_btn_pay_Click(object sender, EventArgs e)
        {
            if (Salary_FNameTb.Text == "" || Salary_FIdCb.SelectedIndex == -1 || SalDeptTb.Text == "" || Sal_AmountTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                cmd = new SqlCommand("Insert into SalaryTbl(F_Id,F_Name,Salary,Department,PayDate)values(@FId,@FN,@Sal,@Dept,@Date)", con);
                cmd.Parameters.AddWithValue("@FId", Salary_FIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@FN", Salary_FNameTb.Text);
                cmd.Parameters.AddWithValue("@Sal", Sal_AmountTb.Text);
                cmd.Parameters.AddWithValue("@Dept", SalDeptTb.Text);
                cmd.Parameters.AddWithValue("@Date", DateTime.Today.Date);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Salary Paid");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void Salary_FIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetFacultyInfo();
        }
        int Key = 0;

        private void salary_btn_reset_Click(object sender, EventArgs e)
        {
            if (Salary_FNameTb.Text == "" || Salary_FIdCb.SelectedIndex == -1 || SalDeptTb.Text == "" || Sal_AmountTb.Text == "")
            {
                MessageBox.Show("Select a Faculty...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from SalaryTbl where Salary_Id=@SKey", con);
                cmd.Parameters.AddWithValue("@SKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Record Deleted");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void salary_datagridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Salary_FIdCb.SelectedValue = salary_datagridview.Rows[e.RowIndex].Cells[1].Value.ToString();
            Salary_FNameTb.Text = salary_datagridview.Rows[e.RowIndex].Cells[2].Value.ToString();
            Sal_AmountTb.Text = salary_datagridview.Rows[e.RowIndex].Cells[4].Value.ToString();
            SalDeptTb.Text = salary_datagridview.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (Salary_FNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(salary_datagridview.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }
    }
}
