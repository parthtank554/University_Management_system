﻿
namespace University_Management_System
{
    partial class DialogBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DialogBox));
            this.icon = new System.Windows.Forms.PictureBox();
            this.DialogBox_Msg = new Guna.UI.WinForms.GunaLabel();
            this.Ok_Btn = new Guna.UI.WinForms.GunaButton();
            this.icon_Delay = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.icon)).BeginInit();
            this.SuspendLayout();
            // 
            // icon
            // 
            this.icon.BackColor = System.Drawing.Color.White;
            this.icon.Image = ((System.Drawing.Image)(resources.GetObject("icon.Image")));
            this.icon.Location = new System.Drawing.Point(56, 13);
            this.icon.Margin = new System.Windows.Forms.Padding(4);
            this.icon.Name = "icon";
            this.icon.Size = new System.Drawing.Size(377, 341);
            this.icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.icon.TabIndex = 0;
            this.icon.TabStop = false;
            // 
            // DialogBox_Msg
            // 
            this.DialogBox_Msg.AutoSize = true;
            this.DialogBox_Msg.BackColor = System.Drawing.Color.Transparent;
            this.DialogBox_Msg.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DialogBox_Msg.Location = new System.Drawing.Point(189, 301);
            this.DialogBox_Msg.Name = "DialogBox_Msg";
            this.DialogBox_Msg.Size = new System.Drawing.Size(105, 28);
            this.DialogBox_Msg.TabIndex = 1;
            this.DialogBox_Msg.Text = "Success";
            // 
            // Ok_Btn
            // 
            this.Ok_Btn.AnimationHoverSpeed = 0.07F;
            this.Ok_Btn.AnimationSpeed = 0.03F;
            this.Ok_Btn.BackColor = System.Drawing.Color.Transparent;
            this.Ok_Btn.BaseColor = System.Drawing.Color.Transparent;
            this.Ok_Btn.BorderColor = System.Drawing.Color.Green;
            this.Ok_Btn.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ok_Btn.ForeColor = System.Drawing.Color.Green;
            this.Ok_Btn.Image = null;
            this.Ok_Btn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Ok_Btn.ImageSize = new System.Drawing.Size(20, 20);
            this.Ok_Btn.Location = new System.Drawing.Point(171, 383);
            this.Ok_Btn.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Ok_Btn.Name = "Ok_Btn";
            this.Ok_Btn.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Ok_Btn.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Ok_Btn.OnHoverForeColor = System.Drawing.Color.White;
            this.Ok_Btn.OnHoverImage = null;
            this.Ok_Btn.OnPressedColor = System.Drawing.Color.Transparent;
            this.Ok_Btn.Radius = 25;
            this.Ok_Btn.Size = new System.Drawing.Size(141, 48);
            this.Ok_Btn.TabIndex = 1;
            this.Ok_Btn.Text = "Ok";
            this.Ok_Btn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Ok_Btn.Click += new System.EventHandler(this.Ok_Btn_Click);
            // 
            // icon_Delay
            // 
            this.icon_Delay.Enabled = true;
            this.icon_Delay.Interval = 6000;
            this.icon_Delay.Tick += new System.EventHandler(this.icon_Delay_Tick);
            // 
            // DialogBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(746, 503);
            this.Controls.Add(this.Ok_Btn);
            this.Controls.Add(this.DialogBox_Msg);
            this.Controls.Add(this.icon);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DialogBox";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogBox";
            this.Load += new System.EventHandler(this.DialogBox_Load);
            ((System.ComponentModel.ISupportInitialize)(this.icon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox icon;
        private Guna.UI.WinForms.GunaLabel DialogBox_Msg;
        private Guna.UI.WinForms.GunaButton Ok_Btn;
        private System.Windows.Forms.Timer icon_Delay;
    }
}