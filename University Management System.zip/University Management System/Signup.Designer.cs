﻿
namespace University_Management_System
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.gunaLinePanel3 = new Guna.UI.WinForms.GunaLinePanel();
            this.CpassTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.createaccount = new Guna.UI.WinForms.GunaLinkLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.Signupbtn = new Guna.UI.WinForms.GunaButton();
            this.ShowPass = new Guna.UI.WinForms.GunaCheckBox();
            this.gunaLinePanel2 = new Guna.UI.WinForms.GunaLinePanel();
            this.PassTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLinePanel1 = new Guna.UI.WinForms.GunaLinePanel();
            this.UserName = new Guna.UI.WinForms.GunaTextBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            this.gunaLinePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            this.gunaLinePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            this.gunaLinePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.gunaPanel1.Controls.Add(this.gunaLabel5);
            this.gunaPanel1.Controls.Add(this.gunaLabel4);
            this.gunaPanel1.Controls.Add(this.gunaLabel3);
            this.gunaPanel1.Controls.Add(this.gunaLabel2);
            this.gunaPanel1.Controls.Add(this.gunaLabel1);
            this.gunaPanel1.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(407, 689);
            this.gunaPanel1.TabIndex = 1;
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(111, 546);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(161, 69);
            this.gunaLabel5.TabIndex = 4;
            this.gunaLabel5.Text = "Yash Ramoliya\r\nYash Vagadiya\r\nParth Tank\r\n";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel4.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(119, 504);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(145, 31);
            this.gunaLabel4.TabIndex = 3;
            this.gunaLabel4.Text = "Design By :";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel3.Font = new System.Drawing.Font("Century Gothic", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(126, 276);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(112, 36);
            this.gunaLabel3.TabIndex = 2;
            this.gunaLabel3.Text = "System";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel2.Font = new System.Drawing.Font("Century Gothic", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(15, 224);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(365, 36);
            this.gunaLabel2.TabIndex = 1;
            this.gunaLabel2.Text = "University Management ";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel1.Font = new System.Drawing.Font("Century Gothic", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(62, 172);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(250, 36);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "Welcome To The";
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.Controls.Add(this.gunaButton1);
            this.gunaPanel2.Controls.Add(this.gunaLinePanel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel9);
            this.gunaPanel2.Controls.Add(this.gunaLabel8);
            this.gunaPanel2.Controls.Add(this.createaccount);
            this.gunaPanel2.Controls.Add(this.gunaLabel7);
            this.gunaPanel2.Controls.Add(this.Signupbtn);
            this.gunaPanel2.Controls.Add(this.ShowPass);
            this.gunaPanel2.Controls.Add(this.gunaLinePanel2);
            this.gunaPanel2.Controls.Add(this.gunaLinePanel1);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel6);
            this.gunaPanel2.Location = new System.Drawing.Point(409, -1);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(616, 689);
            this.gunaPanel2.TabIndex = 2;
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButton1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton1.ForeColor = System.Drawing.Color.Red;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(568, 13);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.Red;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(45, 42);
            this.gunaButton1.TabIndex = 11;
            this.gunaButton1.Text = "X";
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // gunaLinePanel3
            // 
            this.gunaLinePanel3.Controls.Add(this.CpassTb);
            this.gunaLinePanel3.Controls.Add(this.gunaPictureBox3);
            this.gunaLinePanel3.LineColor = System.Drawing.Color.Black;
            this.gunaLinePanel3.LineStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaLinePanel3.Location = new System.Drawing.Point(8, 312);
            this.gunaLinePanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaLinePanel3.Name = "gunaLinePanel3";
            this.gunaLinePanel3.Size = new System.Drawing.Size(600, 73);
            this.gunaLinePanel3.TabIndex = 10;
            // 
            // CpassTb
            // 
            this.CpassTb.BaseColor = System.Drawing.Color.White;
            this.CpassTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.CpassTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CpassTb.FocusedBaseColor = System.Drawing.Color.White;
            this.CpassTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.CpassTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.CpassTb.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpassTb.Location = new System.Drawing.Point(71, 7);
            this.CpassTb.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.CpassTb.Name = "CpassTb";
            this.CpassTb.PasswordChar = '●';
            this.CpassTb.Radius = 8;
            this.CpassTb.Size = new System.Drawing.Size(509, 50);
            this.CpassTb.TabIndex = 1;
            this.CpassTb.UseSystemPasswordChar = true;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.Screenshot_2024_10_13_214517;
            this.gunaPictureBox3.Location = new System.Drawing.Point(8, 5);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(51, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox3.TabIndex = 0;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel9.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.Location = new System.Drawing.Point(67, 582);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(474, 22);
            this.gunaLabel9.TabIndex = 9;
            this.gunaLabel9.Text = "To obtain access this App or any questions about it";
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel8.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(241, 547);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(92, 22);
            this.gunaLabel8.TabIndex = 8;
            this.gunaLabel8.Text = "Support :";
            this.gunaLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createaccount
            // 
            this.createaccount.AutoSize = true;
            this.createaccount.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createaccount.Location = new System.Drawing.Point(334, 503);
            this.createaccount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.createaccount.Name = "createaccount";
            this.createaccount.Size = new System.Drawing.Size(105, 23);
            this.createaccount.TabIndex = 7;
            this.createaccount.TabStop = true;
            this.createaccount.Text = "Login Now";
            this.createaccount.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.createaccount_LinkClicked);
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel7.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(59, 505);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(274, 22);
            this.gunaLabel7.TabIndex = 6;
            this.gunaLabel7.Text = "Already Have An Account? ";
            // 
            // Signupbtn
            // 
            this.Signupbtn.AnimationHoverSpeed = 0.07F;
            this.Signupbtn.AnimationSpeed = 0.03F;
            this.Signupbtn.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.Signupbtn.BorderColor = System.Drawing.Color.Black;
            this.Signupbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Signupbtn.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signupbtn.ForeColor = System.Drawing.Color.White;
            this.Signupbtn.Image = null;
            this.Signupbtn.ImageSize = new System.Drawing.Size(20, 20);
            this.Signupbtn.Location = new System.Drawing.Point(56, 427);
            this.Signupbtn.Margin = new System.Windows.Forms.Padding(4);
            this.Signupbtn.Name = "Signupbtn";
            this.Signupbtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.Signupbtn.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Signupbtn.OnHoverForeColor = System.Drawing.Color.White;
            this.Signupbtn.OnHoverImage = null;
            this.Signupbtn.OnPressedColor = System.Drawing.Color.Black;
            this.Signupbtn.Radius = 8;
            this.Signupbtn.Size = new System.Drawing.Size(509, 53);
            this.Signupbtn.TabIndex = 3;
            this.Signupbtn.Text = "Sign Up";
            this.Signupbtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Signupbtn.Click += new System.EventHandler(this.Signupbtn_Click);
            // 
            // ShowPass
            // 
            this.ShowPass.BaseColor = System.Drawing.Color.White;
            this.ShowPass.CheckedOffColor = System.Drawing.Color.Gray;
            this.ShowPass.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ShowPass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowPass.FillColor = System.Drawing.Color.White;
            this.ShowPass.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowPass.Location = new System.Drawing.Point(404, 387);
            this.ShowPass.Name = "ShowPass";
            this.ShowPass.Size = new System.Drawing.Size(172, 26);
            this.ShowPass.TabIndex = 5;
            this.ShowPass.Text = "Show Password";
            this.ShowPass.CheckedChanged += new System.EventHandler(this.ShowPass_CheckedChanged);
            // 
            // gunaLinePanel2
            // 
            this.gunaLinePanel2.Controls.Add(this.PassTb);
            this.gunaLinePanel2.Controls.Add(this.gunaPictureBox2);
            this.gunaLinePanel2.LineColor = System.Drawing.Color.Black;
            this.gunaLinePanel2.LineStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaLinePanel2.Location = new System.Drawing.Point(5, 231);
            this.gunaLinePanel2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaLinePanel2.Name = "gunaLinePanel2";
            this.gunaLinePanel2.Size = new System.Drawing.Size(600, 73);
            this.gunaLinePanel2.TabIndex = 4;
            // 
            // PassTb
            // 
            this.PassTb.BaseColor = System.Drawing.Color.White;
            this.PassTb.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.PassTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PassTb.FocusedBaseColor = System.Drawing.Color.White;
            this.PassTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.PassTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.PassTb.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassTb.Location = new System.Drawing.Point(71, 7);
            this.PassTb.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.PassTb.Name = "PassTb";
            this.PassTb.PasswordChar = '●';
            this.PassTb.Radius = 8;
            this.PassTb.Size = new System.Drawing.Size(509, 50);
            this.PassTb.TabIndex = 1;
            this.PassTb.UseSystemPasswordChar = true;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.Screenshot_2024_10_13_214517;
            this.gunaPictureBox2.Location = new System.Drawing.Point(8, 5);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(51, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox2.TabIndex = 0;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaLinePanel1
            // 
            this.gunaLinePanel1.Controls.Add(this.UserName);
            this.gunaLinePanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaLinePanel1.LineColor = System.Drawing.Color.Black;
            this.gunaLinePanel1.LineStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaLinePanel1.Location = new System.Drawing.Point(6, 144);
            this.gunaLinePanel1.Margin = new System.Windows.Forms.Padding(4);
            this.gunaLinePanel1.Name = "gunaLinePanel1";
            this.gunaLinePanel1.Size = new System.Drawing.Size(600, 73);
            this.gunaLinePanel1.TabIndex = 2;
            // 
            // UserName
            // 
            this.UserName.BaseColor = System.Drawing.Color.White;
            this.UserName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(218)))), ((int)(((byte)(223)))));
            this.UserName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.UserName.FocusedBaseColor = System.Drawing.Color.White;
            this.UserName.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.UserName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.UserName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.Location = new System.Drawing.Point(71, 8);
            this.UserName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.UserName.Name = "UserName";
            this.UserName.PasswordChar = '\0';
            this.UserName.Radius = 8;
            this.UserName.Size = new System.Drawing.Size(509, 50);
            this.UserName.TabIndex = 1;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.Screenshot_2024_10_13_214351;
            this.gunaPictureBox1.Location = new System.Drawing.Point(8, 5);
            this.gunaPictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(51, 52);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.gunaPanel3.Location = new System.Drawing.Point(45, 104);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(330, 10);
            this.gunaPanel3.TabIndex = 3;
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel6.Font = new System.Drawing.Font("Century Gothic", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(39, 54);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(320, 36);
            this.gunaLabel6.TabIndex = 2;
            this.gunaLabel6.Text = "Create New Account";
            // 
            // Signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 687);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Signup";
            this.Text = "Signup";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            this.gunaLinePanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            this.gunaLinePanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            this.gunaLinePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaLinePanel gunaLinePanel3;
        private Guna.UI.WinForms.GunaTextBox CpassTb;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaLinkLabel createaccount;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaButton Signupbtn;
        private Guna.UI.WinForms.GunaCheckBox ShowPass;
        private Guna.UI.WinForms.GunaLinePanel gunaLinePanel2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaLinePanel gunaLinePanel1;
        private Guna.UI.WinForms.GunaTextBox UserName;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private Guna.UI.WinForms.GunaTextBox PassTb;
    }
}