﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Login : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand user_cmd;
        public Login()
        {
            InitializeComponent();
        }

        private void createaccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup sign = new Signup();
            this.Hide();
            sign.Show();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPass.Checked)
            {
                Password_Tb.UseSystemPasswordChar = false;
            }
            else
            {
                Password_Tb.UseSystemPasswordChar = true;
            }
        }

        private void PasswordTb_TextChanged(object sender, EventArgs e)
        {
            Password_Tb.UseSystemPasswordChar = true;
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            show();
        }
        public void show()
        {
            if (User_NameTb.Text == "" || Password_Tb.Text == "")
            {
                MessageBox.Show("Please Enter Credentials...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                user_cmd = new SqlCommand("Select * from User_Tbl where User_Name='"+User_NameTb.Text+"' and Password='"+Password_Tb.Text+"'", con);
                SqlDataAdapter adpt = new SqlDataAdapter(user_cmd);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                con.Close();
                if (dt.Rows.Count == 1)
                {
                    Menu home = new Menu();
                    DialogBox Db = new DialogBox("Success");
                    Db.ShowDialog();
                    this.Hide();
                    home.Show();

                }
                else
                {
                    MessageBox.Show("Wrong Username Or Password...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
    }
}
