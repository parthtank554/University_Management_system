﻿
namespace University_Management_System
{
    partial class Faculty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_logout = new Guna.UI.WinForms.GunaButton();
            this.btn_campus = new Guna.UI.WinForms.GunaButton();
            this.btn_salary = new Guna.UI.WinForms.GunaButton();
            this.btn_fees = new Guna.UI.WinForms.GunaButton();
            this.btn_course = new Guna.UI.WinForms.GunaButton();
            this.btn_faculty = new Guna.UI.WinForms.GunaButton();
            this.btn_department = new Guna.UI.WinForms.GunaButton();
            this.Btn_student = new Guna.UI.WinForms.GunaButton();
            this.Btn_Home = new Guna.UI.WinForms.GunaButton();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.lblcampus = new Guna.UI.WinForms.GunaLabel();
            this.lblsalary = new Guna.UI.WinForms.GunaLabel();
            this.lblfees = new Guna.UI.WinForms.GunaLabel();
            this.lblcourse = new Guna.UI.WinForms.GunaLabel();
            this.lblfaculty = new Guna.UI.WinForms.GunaLabel();
            this.lblstudent = new Guna.UI.WinForms.GunaLabel();
            this.lblhome = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.ExperienceTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.QualificationCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.F_DeptIdCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.F_GenderCb = new Guna.UI.WinForms.GunaComboBox();
            this.F_AddressTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.faculty_exit = new Guna.UI.WinForms.GunaButton();
            this.Faculty_DGV = new Guna.UI.WinForms.GunaDataGridView();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.faculty_delete = new Guna.UI.WinForms.GunaButton();
            this.faculty_edit = new Guna.UI.WinForms.GunaButton();
            this.faculty_save = new Guna.UI.WinForms.GunaButton();
            this.F_DOBdt = new System.Windows.Forms.DateTimePicker();
            this.F_SalaryTb = new Guna.UI.WinForms.GunaTextBox();
            this.F_DeptTb = new Guna.UI.WinForms.GunaTextBox();
            this.F_NameTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Faculty_DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_logout
            // 
            this.btn_logout.AnimationHoverSpeed = 0.07F;
            this.btn_logout.AnimationSpeed = 0.03F;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.BaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.BorderColor = System.Drawing.Color.Black;
            this.btn_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_logout.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Black;
            this.btn_logout.Image = null;
            this.btn_logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_logout.Location = new System.Drawing.Point(111, 760);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_logout.OnHoverImage = null;
            this.btn_logout.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_logout.Radius = 8;
            this.btn_logout.Size = new System.Drawing.Size(160, 42);
            this.btn_logout.TabIndex = 46;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_campus
            // 
            this.btn_campus.AnimationHoverSpeed = 0.07F;
            this.btn_campus.AnimationSpeed = 0.03F;
            this.btn_campus.BackColor = System.Drawing.Color.Transparent;
            this.btn_campus.BaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.BorderColor = System.Drawing.Color.Black;
            this.btn_campus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_campus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_campus.ForeColor = System.Drawing.Color.Black;
            this.btn_campus.Image = null;
            this.btn_campus.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_campus.Location = new System.Drawing.Point(111, 683);
            this.btn_campus.Name = "btn_campus";
            this.btn_campus.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_campus.OnHoverImage = null;
            this.btn_campus.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_campus.Radius = 8;
            this.btn_campus.Size = new System.Drawing.Size(160, 42);
            this.btn_campus.TabIndex = 45;
            this.btn_campus.Text = "Campus";
            this.btn_campus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.Click += new System.EventHandler(this.btn_campus_Click);
            // 
            // btn_salary
            // 
            this.btn_salary.AnimationHoverSpeed = 0.07F;
            this.btn_salary.AnimationSpeed = 0.03F;
            this.btn_salary.BackColor = System.Drawing.Color.Transparent;
            this.btn_salary.BaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.BorderColor = System.Drawing.Color.Black;
            this.btn_salary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_salary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary.ForeColor = System.Drawing.Color.Black;
            this.btn_salary.Image = null;
            this.btn_salary.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_salary.Location = new System.Drawing.Point(111, 607);
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_salary.OnHoverImage = null;
            this.btn_salary.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_salary.Radius = 8;
            this.btn_salary.Size = new System.Drawing.Size(160, 42);
            this.btn_salary.TabIndex = 44;
            this.btn_salary.Text = "Salary";
            this.btn_salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_fees
            // 
            this.btn_fees.AnimationHoverSpeed = 0.07F;
            this.btn_fees.AnimationSpeed = 0.03F;
            this.btn_fees.BackColor = System.Drawing.Color.Transparent;
            this.btn_fees.BaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.BorderColor = System.Drawing.Color.Black;
            this.btn_fees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fees.ForeColor = System.Drawing.Color.Black;
            this.btn_fees.Image = null;
            this.btn_fees.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_fees.Location = new System.Drawing.Point(111, 521);
            this.btn_fees.Name = "btn_fees";
            this.btn_fees.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_fees.OnHoverImage = null;
            this.btn_fees.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_fees.Radius = 8;
            this.btn_fees.Size = new System.Drawing.Size(160, 42);
            this.btn_fees.TabIndex = 43;
            this.btn_fees.Text = "Fees";
            this.btn_fees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.Click += new System.EventHandler(this.btn_fees_Click);
            // 
            // btn_course
            // 
            this.btn_course.AnimationHoverSpeed = 0.07F;
            this.btn_course.AnimationSpeed = 0.03F;
            this.btn_course.BackColor = System.Drawing.Color.Transparent;
            this.btn_course.BaseColor = System.Drawing.Color.Transparent;
            this.btn_course.BorderColor = System.Drawing.Color.Black;
            this.btn_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_course.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_course.ForeColor = System.Drawing.Color.Black;
            this.btn_course.Image = null;
            this.btn_course.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_course.Location = new System.Drawing.Point(123, 446);
            this.btn_course.Name = "btn_course";
            this.btn_course.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_course.OnHoverImage = null;
            this.btn_course.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_course.Radius = 8;
            this.btn_course.Size = new System.Drawing.Size(160, 42);
            this.btn_course.TabIndex = 42;
            this.btn_course.Text = "Courses";
            this.btn_course.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.Click += new System.EventHandler(this.btn_course_Click);
            // 
            // btn_faculty
            // 
            this.btn_faculty.AnimationHoverSpeed = 0.07F;
            this.btn_faculty.AnimationSpeed = 0.03F;
            this.btn_faculty.BackColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BorderColor = System.Drawing.Color.Black;
            this.btn_faculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_faculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_faculty.ForeColor = System.Drawing.Color.Black;
            this.btn_faculty.Image = null;
            this.btn_faculty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_faculty.Location = new System.Drawing.Point(123, 364);
            this.btn_faculty.Name = "btn_faculty";
            this.btn_faculty.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_faculty.OnHoverImage = null;
            this.btn_faculty.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_faculty.Radius = 8;
            this.btn_faculty.Size = new System.Drawing.Size(160, 42);
            this.btn_faculty.TabIndex = 41;
            this.btn_faculty.Text = "Faculty";
            this.btn_faculty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.Click += new System.EventHandler(this.btn_faculty_Click);
            // 
            // btn_department
            // 
            this.btn_department.AnimationHoverSpeed = 0.07F;
            this.btn_department.AnimationSpeed = 0.03F;
            this.btn_department.BackColor = System.Drawing.Color.Transparent;
            this.btn_department.BaseColor = System.Drawing.Color.Transparent;
            this.btn_department.BorderColor = System.Drawing.Color.Black;
            this.btn_department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_department.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_department.ForeColor = System.Drawing.Color.Black;
            this.btn_department.Image = null;
            this.btn_department.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_department.Location = new System.Drawing.Point(123, 288);
            this.btn_department.Name = "btn_department";
            this.btn_department.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_department.OnHoverImage = null;
            this.btn_department.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_department.Radius = 8;
            this.btn_department.Size = new System.Drawing.Size(160, 42);
            this.btn_department.TabIndex = 40;
            this.btn_department.Text = "Department";
            this.btn_department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.Click += new System.EventHandler(this.btn_department_Click);
            // 
            // Btn_student
            // 
            this.Btn_student.AnimationHoverSpeed = 0.07F;
            this.Btn_student.AnimationSpeed = 0.03F;
            this.Btn_student.BackColor = System.Drawing.Color.Transparent;
            this.Btn_student.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.BorderColor = System.Drawing.Color.Black;
            this.Btn_student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_student.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_student.ForeColor = System.Drawing.Color.Black;
            this.Btn_student.Image = null;
            this.Btn_student.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_student.Location = new System.Drawing.Point(111, 202);
            this.Btn_student.Name = "Btn_student";
            this.Btn_student.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_student.OnHoverImage = null;
            this.Btn_student.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_student.Radius = 8;
            this.Btn_student.Size = new System.Drawing.Size(160, 42);
            this.Btn_student.TabIndex = 39;
            this.Btn_student.Text = "Student";
            this.Btn_student.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.Click += new System.EventHandler(this.Btn_student_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.AnimationHoverSpeed = 0.07F;
            this.Btn_Home.AnimationSpeed = 0.03F;
            this.Btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BorderColor = System.Drawing.Color.Black;
            this.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Home.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Home.ForeColor = System.Drawing.Color.Black;
            this.Btn_Home.Image = null;
            this.Btn_Home.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_Home.Location = new System.Drawing.Point(111, 135);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_Home.OnHoverImage = null;
            this.Btn_Home.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_Home.Radius = 8;
            this.Btn_Home.Size = new System.Drawing.Size(160, 42);
            this.Btn_Home.TabIndex = 38;
            this.Btn_Home.Text = "Home";
            this.Btn_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.gunaPanel1.Controls.Add(this.btn_logout);
            this.gunaPanel1.Controls.Add(this.btn_campus);
            this.gunaPanel1.Controls.Add(this.btn_salary);
            this.gunaPanel1.Controls.Add(this.btn_fees);
            this.gunaPanel1.Controls.Add(this.btn_course);
            this.gunaPanel1.Controls.Add(this.btn_faculty);
            this.gunaPanel1.Controls.Add(this.btn_department);
            this.gunaPanel1.Controls.Add(this.Btn_student);
            this.gunaPanel1.Controls.Add(this.Btn_Home);
            this.gunaPanel1.Controls.Add(this.lblcampus);
            this.gunaPanel1.Controls.Add(this.lblsalary);
            this.gunaPanel1.Controls.Add(this.lblfees);
            this.gunaPanel1.Controls.Add(this.lblcourse);
            this.gunaPanel1.Controls.Add(this.lblfaculty);
            this.gunaPanel1.Controls.Add(this.lblstudent);
            this.gunaPanel1.Controls.Add(this.lblhome);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox8);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox7);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel1.Location = new System.Drawing.Point(1, -33);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(311, 914);
            this.gunaPanel1.TabIndex = 2;
            // 
            // lblcampus
            // 
            this.lblcampus.AutoSize = true;
            this.lblcampus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcampus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcampus.Location = new System.Drawing.Point(131, 688);
            this.lblcampus.Name = "lblcampus";
            this.lblcampus.Size = new System.Drawing.Size(95, 26);
            this.lblcampus.TabIndex = 18;
            this.lblcampus.Text = "Campus";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblsalary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(131, 607);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(79, 26);
            this.lblsalary.TabIndex = 17;
            this.lblsalary.Text = "Salary";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfees.Location = new System.Drawing.Point(131, 524);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(58, 26);
            this.lblfees.TabIndex = 16;
            this.lblfees.Text = "Fees";
            this.lblfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcourse.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourse.Location = new System.Drawing.Point(131, 446);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(85, 26);
            this.lblcourse.TabIndex = 15;
            this.lblcourse.Text = "Course";
            // 
            // lblfaculty
            // 
            this.lblfaculty.AutoSize = true;
            this.lblfaculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfaculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfaculty.Location = new System.Drawing.Point(131, 366);
            this.lblfaculty.Name = "lblfaculty";
            this.lblfaculty.Size = new System.Drawing.Size(90, 26);
            this.lblfaculty.TabIndex = 14;
            this.lblfaculty.Text = "Faculty";
            // 
            // lblstudent
            // 
            this.lblstudent.AutoSize = true;
            this.lblstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblstudent.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudent.Location = new System.Drawing.Point(131, 211);
            this.lblstudent.Name = "lblstudent";
            this.lblstudent.Size = new System.Drawing.Size(91, 26);
            this.lblstudent.TabIndex = 12;
            this.lblstudent.Text = "Student";
            // 
            // lblhome
            // 
            this.lblhome.AutoSize = true;
            this.lblhome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblhome.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhome.Location = new System.Drawing.Point(131, 138);
            this.lblhome.Name = "lblhome";
            this.lblhome.Size = new System.Drawing.Size(73, 26);
            this.lblhome.TabIndex = 11;
            this.lblhome.Text = "Home";
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Image = global::University_Management_System.Properties.Resources.logout;
            this.gunaPictureBox10.Location = new System.Drawing.Point(44, 754);
            this.gunaPictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 9;
            this.gunaPictureBox10.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::University_Management_System.Properties.Resources.campus;
            this.gunaPictureBox9.Location = new System.Drawing.Point(44, 673);
            this.gunaPictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 8;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::University_Management_System.Properties.Resources.salary;
            this.gunaPictureBox8.Location = new System.Drawing.Point(44, 598);
            this.gunaPictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 7;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::University_Management_System.Properties.Resources.fees;
            this.gunaPictureBox7.Location = new System.Drawing.Point(44, 515);
            this.gunaPictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 6;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::University_Management_System.Properties.Resources.course;
            this.gunaPictureBox6.Location = new System.Drawing.Point(44, 437);
            this.gunaPictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 5;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::University_Management_System.Properties.Resources.faculty;
            this.gunaPictureBox5.Location = new System.Drawing.Point(44, 354);
            this.gunaPictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::University_Management_System.Properties.Resources.Department;
            this.gunaPictureBox4.Location = new System.Drawing.Point(44, 278);
            this.gunaPictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.student;
            this.gunaPictureBox3.Location = new System.Drawing.Point(44, 201);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.home;
            this.gunaPictureBox2.Location = new System.Drawing.Point(44, 129);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.university;
            this.gunaPictureBox1.Location = new System.Drawing.Point(123, 44);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(73, 60);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.White;
            this.gunaPanel2.Controls.Add(this.ExperienceTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel8);
            this.gunaPanel2.Controls.Add(this.QualificationCb);
            this.gunaPanel2.Controls.Add(this.gunaLabel11);
            this.gunaPanel2.Controls.Add(this.F_DeptIdCb);
            this.gunaPanel2.Controls.Add(this.gunaLabel10);
            this.gunaPanel2.Controls.Add(this.F_GenderCb);
            this.gunaPanel2.Controls.Add(this.F_AddressTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel9);
            this.gunaPanel2.Controls.Add(this.faculty_exit);
            this.gunaPanel2.Controls.Add(this.Faculty_DGV);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.faculty_delete);
            this.gunaPanel2.Controls.Add(this.faculty_edit);
            this.gunaPanel2.Controls.Add(this.faculty_save);
            this.gunaPanel2.Controls.Add(this.F_DOBdt);
            this.gunaPanel2.Controls.Add(this.F_SalaryTb);
            this.gunaPanel2.Controls.Add(this.F_DeptTb);
            this.gunaPanel2.Controls.Add(this.F_NameTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel7);
            this.gunaPanel2.Controls.Add(this.gunaLabel5);
            this.gunaPanel2.Controls.Add(this.gunaLabel4);
            this.gunaPanel2.Controls.Add(this.gunaLabel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel6);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Location = new System.Drawing.Point(309, -2);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(914, 911);
            this.gunaPanel2.TabIndex = 21;
            // 
            // ExperienceTb
            // 
            this.ExperienceTb.BaseColor = System.Drawing.Color.White;
            this.ExperienceTb.BorderColor = System.Drawing.Color.Silver;
            this.ExperienceTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ExperienceTb.FocusedBaseColor = System.Drawing.Color.White;
            this.ExperienceTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.ExperienceTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.ExperienceTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ExperienceTb.Location = new System.Drawing.Point(555, 435);
            this.ExperienceTb.Margin = new System.Windows.Forms.Padding(4);
            this.ExperienceTb.Name = "ExperienceTb";
            this.ExperienceTb.PasswordChar = '\0';
            this.ExperienceTb.Radius = 5;
            this.ExperienceTb.Size = new System.Drawing.Size(205, 32);
            this.ExperienceTb.TabIndex = 94;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel8.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(549, 395);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(148, 28);
            this.gunaLabel8.TabIndex = 93;
            this.gunaLabel8.Text = "Experience";
            // 
            // QualificationCb
            // 
            this.QualificationCb.BackColor = System.Drawing.Color.Transparent;
            this.QualificationCb.BaseColor = System.Drawing.Color.White;
            this.QualificationCb.BorderColor = System.Drawing.Color.Silver;
            this.QualificationCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.QualificationCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.QualificationCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.QualificationCb.ForeColor = System.Drawing.Color.Black;
            this.QualificationCb.FormattingEnabled = true;
            this.QualificationCb.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.QualificationCb.Location = new System.Drawing.Point(314, 431);
            this.QualificationCb.Margin = new System.Windows.Forms.Padding(4);
            this.QualificationCb.Name = "QualificationCb";
            this.QualificationCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.QualificationCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.QualificationCb.Radius = 5;
            this.QualificationCb.Size = new System.Drawing.Size(205, 31);
            this.QualificationCb.TabIndex = 92;
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.AutoSize = true;
            this.gunaLabel11.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel11.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel11.Location = new System.Drawing.Point(308, 395);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(175, 28);
            this.gunaLabel11.TabIndex = 91;
            this.gunaLabel11.Text = "Qualification";
            // 
            // F_DeptIdCb
            // 
            this.F_DeptIdCb.BackColor = System.Drawing.Color.Transparent;
            this.F_DeptIdCb.BaseColor = System.Drawing.Color.White;
            this.F_DeptIdCb.BorderColor = System.Drawing.Color.Silver;
            this.F_DeptIdCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.F_DeptIdCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.F_DeptIdCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.F_DeptIdCb.ForeColor = System.Drawing.Color.Black;
            this.F_DeptIdCb.FormattingEnabled = true;
            this.F_DeptIdCb.Location = new System.Drawing.Point(314, 312);
            this.F_DeptIdCb.Margin = new System.Windows.Forms.Padding(4);
            this.F_DeptIdCb.Name = "F_DeptIdCb";
            this.F_DeptIdCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_DeptIdCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.F_DeptIdCb.Radius = 5;
            this.F_DeptIdCb.Size = new System.Drawing.Size(205, 31);
            this.F_DeptIdCb.TabIndex = 90;
            this.F_DeptIdCb.SelectionChangeCommitted += new System.EventHandler(this.F_DeptIdCb_SelectionChangeCommitted);
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel10.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel10.Location = new System.Drawing.Point(308, 276);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(106, 28);
            this.gunaLabel10.TabIndex = 89;
            this.gunaLabel10.Text = "Dept Id";
            // 
            // F_GenderCb
            // 
            this.F_GenderCb.BackColor = System.Drawing.Color.Transparent;
            this.F_GenderCb.BaseColor = System.Drawing.Color.White;
            this.F_GenderCb.BorderColor = System.Drawing.Color.Silver;
            this.F_GenderCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.F_GenderCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.F_GenderCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.F_GenderCb.ForeColor = System.Drawing.Color.Black;
            this.F_GenderCb.FormattingEnabled = true;
            this.F_GenderCb.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.F_GenderCb.Location = new System.Drawing.Point(320, 195);
            this.F_GenderCb.Margin = new System.Windows.Forms.Padding(4);
            this.F_GenderCb.Name = "F_GenderCb";
            this.F_GenderCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_GenderCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.F_GenderCb.Radius = 5;
            this.F_GenderCb.Size = new System.Drawing.Size(205, 31);
            this.F_GenderCb.TabIndex = 88;
            // 
            // F_AddressTb
            // 
            this.F_AddressTb.BaseColor = System.Drawing.Color.White;
            this.F_AddressTb.BorderColor = System.Drawing.Color.Silver;
            this.F_AddressTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.F_AddressTb.FocusedBaseColor = System.Drawing.Color.White;
            this.F_AddressTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_AddressTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.F_AddressTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.F_AddressTb.Location = new System.Drawing.Point(52, 430);
            this.F_AddressTb.Margin = new System.Windows.Forms.Padding(4);
            this.F_AddressTb.MultiLine = true;
            this.F_AddressTb.Name = "F_AddressTb";
            this.F_AddressTb.PasswordChar = '\0';
            this.F_AddressTb.Radius = 5;
            this.F_AddressTb.Size = new System.Drawing.Size(205, 32);
            this.F_AddressTb.TabIndex = 87;
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel9.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.Location = new System.Drawing.Point(46, 395);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(115, 28);
            this.gunaLabel9.TabIndex = 86;
            this.gunaLabel9.Text = "Address";
            // 
            // faculty_exit
            // 
            this.faculty_exit.AnimationHoverSpeed = 0.07F;
            this.faculty_exit.AnimationSpeed = 0.03F;
            this.faculty_exit.BaseColor = System.Drawing.Color.Transparent;
            this.faculty_exit.BorderColor = System.Drawing.Color.Black;
            this.faculty_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.faculty_exit.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faculty_exit.ForeColor = System.Drawing.Color.Red;
            this.faculty_exit.Image = null;
            this.faculty_exit.ImageSize = new System.Drawing.Size(20, 20);
            this.faculty_exit.Location = new System.Drawing.Point(843, 22);
            this.faculty_exit.Name = "faculty_exit";
            this.faculty_exit.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.faculty_exit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.faculty_exit.OnHoverForeColor = System.Drawing.Color.Red;
            this.faculty_exit.OnHoverImage = null;
            this.faculty_exit.OnPressedColor = System.Drawing.Color.Black;
            this.faculty_exit.Size = new System.Drawing.Size(45, 42);
            this.faculty_exit.TabIndex = 69;
            this.faculty_exit.Text = "X";
            this.faculty_exit.Click += new System.EventHandler(this.faculty_exit_Click);
            // 
            // Faculty_DGV
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            this.Faculty_DGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.Faculty_DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Faculty_DGV.BackgroundColor = System.Drawing.Color.White;
            this.Faculty_DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Faculty_DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Faculty_DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Faculty_DGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.Faculty_DGV.ColumnHeadersHeight = 4;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Faculty_DGV.DefaultCellStyle = dataGridViewCellStyle12;
            this.Faculty_DGV.EnableHeadersVisualStyles = false;
            this.Faculty_DGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Faculty_DGV.Location = new System.Drawing.Point(6, 576);
            this.Faculty_DGV.Margin = new System.Windows.Forms.Padding(4);
            this.Faculty_DGV.Name = "Faculty_DGV";
            this.Faculty_DGV.RowHeadersVisible = false;
            this.Faculty_DGV.RowHeadersWidth = 51;
            this.Faculty_DGV.RowTemplate.Height = 24;
            this.Faculty_DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Faculty_DGV.Size = new System.Drawing.Size(904, 249);
            this.Faculty_DGV.TabIndex = 85;
            this.Faculty_DGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.Faculty_DGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Faculty_DGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Faculty_DGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Faculty_DGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Faculty_DGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Faculty_DGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Faculty_DGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Faculty_DGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Faculty_DGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Faculty_DGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Faculty_DGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Faculty_DGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Faculty_DGV.ThemeStyle.HeaderStyle.Height = 4;
            this.Faculty_DGV.ThemeStyle.ReadOnly = false;
            this.Faculty_DGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Faculty_DGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Faculty_DGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Faculty_DGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Faculty_DGV.ThemeStyle.RowsStyle.Height = 24;
            this.Faculty_DGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Faculty_DGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Faculty_DGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Faculty_DGV_CellContentClick);
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPanel3.Location = new System.Drawing.Point(1, 564);
            this.gunaPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(1041, 6);
            this.gunaPanel3.TabIndex = 84;
            // 
            // faculty_delete
            // 
            this.faculty_delete.AnimationHoverSpeed = 0.07F;
            this.faculty_delete.AnimationSpeed = 0.03F;
            this.faculty_delete.BackColor = System.Drawing.Color.Transparent;
            this.faculty_delete.BaseColor = System.Drawing.Color.Transparent;
            this.faculty_delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.faculty_delete.BorderSize = 2;
            this.faculty_delete.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faculty_delete.ForeColor = System.Drawing.Color.Black;
            this.faculty_delete.Image = null;
            this.faculty_delete.ImageSize = new System.Drawing.Size(20, 20);
            this.faculty_delete.Location = new System.Drawing.Point(589, 492);
            this.faculty_delete.Margin = new System.Windows.Forms.Padding(4);
            this.faculty_delete.Name = "faculty_delete";
            this.faculty_delete.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.faculty_delete.OnHoverBorderColor = System.Drawing.Color.Black;
            this.faculty_delete.OnHoverForeColor = System.Drawing.Color.White;
            this.faculty_delete.OnHoverImage = null;
            this.faculty_delete.OnPressedColor = System.Drawing.Color.Black;
            this.faculty_delete.Radius = 8;
            this.faculty_delete.Size = new System.Drawing.Size(132, 53);
            this.faculty_delete.TabIndex = 83;
            this.faculty_delete.Text = "Delete";
            this.faculty_delete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.faculty_delete.Click += new System.EventHandler(this.faculty_delete_Click);
            // 
            // faculty_edit
            // 
            this.faculty_edit.AnimationHoverSpeed = 0.07F;
            this.faculty_edit.AnimationSpeed = 0.03F;
            this.faculty_edit.BackColor = System.Drawing.Color.Transparent;
            this.faculty_edit.BaseColor = System.Drawing.Color.Transparent;
            this.faculty_edit.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.faculty_edit.BorderSize = 2;
            this.faculty_edit.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faculty_edit.ForeColor = System.Drawing.Color.Black;
            this.faculty_edit.Image = null;
            this.faculty_edit.ImageSize = new System.Drawing.Size(20, 20);
            this.faculty_edit.Location = new System.Drawing.Point(348, 492);
            this.faculty_edit.Margin = new System.Windows.Forms.Padding(4);
            this.faculty_edit.Name = "faculty_edit";
            this.faculty_edit.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.faculty_edit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.faculty_edit.OnHoverForeColor = System.Drawing.Color.White;
            this.faculty_edit.OnHoverImage = null;
            this.faculty_edit.OnPressedColor = System.Drawing.Color.Black;
            this.faculty_edit.Radius = 8;
            this.faculty_edit.Size = new System.Drawing.Size(132, 53);
            this.faculty_edit.TabIndex = 82;
            this.faculty_edit.Text = "Edit";
            this.faculty_edit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.faculty_edit.Click += new System.EventHandler(this.faculty_edit_Click);
            // 
            // faculty_save
            // 
            this.faculty_save.AnimationHoverSpeed = 0.07F;
            this.faculty_save.AnimationSpeed = 0.03F;
            this.faculty_save.BackColor = System.Drawing.Color.Transparent;
            this.faculty_save.BaseColor = System.Drawing.Color.Transparent;
            this.faculty_save.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.faculty_save.BorderSize = 2;
            this.faculty_save.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faculty_save.ForeColor = System.Drawing.Color.Black;
            this.faculty_save.Image = null;
            this.faculty_save.ImageSize = new System.Drawing.Size(20, 20);
            this.faculty_save.Location = new System.Drawing.Point(80, 493);
            this.faculty_save.Margin = new System.Windows.Forms.Padding(4);
            this.faculty_save.Name = "faculty_save";
            this.faculty_save.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.faculty_save.OnHoverBorderColor = System.Drawing.Color.Black;
            this.faculty_save.OnHoverForeColor = System.Drawing.Color.White;
            this.faculty_save.OnHoverImage = null;
            this.faculty_save.OnPressedColor = System.Drawing.Color.Black;
            this.faculty_save.Radius = 8;
            this.faculty_save.Size = new System.Drawing.Size(132, 53);
            this.faculty_save.TabIndex = 81;
            this.faculty_save.Text = "Save";
            this.faculty_save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.faculty_save.Click += new System.EventHandler(this.faculty_save_Click);
            // 
            // F_DOBdt
            // 
            this.F_DOBdt.Location = new System.Drawing.Point(562, 200);
            this.F_DOBdt.Margin = new System.Windows.Forms.Padding(4);
            this.F_DOBdt.Name = "F_DOBdt";
            this.F_DOBdt.Size = new System.Drawing.Size(205, 22);
            this.F_DOBdt.TabIndex = 80;
            this.F_DOBdt.Value = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            // 
            // F_SalaryTb
            // 
            this.F_SalaryTb.BaseColor = System.Drawing.Color.White;
            this.F_SalaryTb.BorderColor = System.Drawing.Color.Silver;
            this.F_SalaryTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.F_SalaryTb.FocusedBaseColor = System.Drawing.Color.White;
            this.F_SalaryTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_SalaryTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.F_SalaryTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.F_SalaryTb.Location = new System.Drawing.Point(52, 311);
            this.F_SalaryTb.Margin = new System.Windows.Forms.Padding(4);
            this.F_SalaryTb.Name = "F_SalaryTb";
            this.F_SalaryTb.PasswordChar = '\0';
            this.F_SalaryTb.Radius = 5;
            this.F_SalaryTb.Size = new System.Drawing.Size(205, 32);
            this.F_SalaryTb.TabIndex = 79;
            // 
            // F_DeptTb
            // 
            this.F_DeptTb.BaseColor = System.Drawing.Color.White;
            this.F_DeptTb.BorderColor = System.Drawing.Color.Silver;
            this.F_DeptTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.F_DeptTb.FocusedBaseColor = System.Drawing.Color.White;
            this.F_DeptTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_DeptTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.F_DeptTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.F_DeptTb.Location = new System.Drawing.Point(555, 316);
            this.F_DeptTb.Margin = new System.Windows.Forms.Padding(4);
            this.F_DeptTb.Name = "F_DeptTb";
            this.F_DeptTb.PasswordChar = '\0';
            this.F_DeptTb.Radius = 5;
            this.F_DeptTb.Size = new System.Drawing.Size(205, 32);
            this.F_DeptTb.TabIndex = 78;
            // 
            // F_NameTb
            // 
            this.F_NameTb.BaseColor = System.Drawing.Color.White;
            this.F_NameTb.BorderColor = System.Drawing.Color.Silver;
            this.F_NameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.F_NameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.F_NameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.F_NameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.F_NameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.F_NameTb.Location = new System.Drawing.Point(52, 199);
            this.F_NameTb.Margin = new System.Windows.Forms.Padding(4);
            this.F_NameTb.Name = "F_NameTb";
            this.F_NameTb.PasswordChar = '\0';
            this.F_NameTb.Radius = 5;
            this.F_NameTb.Size = new System.Drawing.Size(205, 32);
            this.F_NameTb.TabIndex = 77;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel7.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(314, 159);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(103, 28);
            this.gunaLabel7.TabIndex = 76;
            this.gunaLabel7.Text = "Gender";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel5.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(556, 159);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(176, 28);
            this.gunaLabel5.TabIndex = 75;
            this.gunaLabel5.Text = "Date Of Birth";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel4.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(46, 276);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(88, 28);
            this.gunaLabel4.TabIndex = 74;
            this.gunaLabel4.Text = "Salary";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel3.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(549, 276);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(151, 28);
            this.gunaLabel3.TabIndex = 73;
            this.gunaLabel3.Text = "Dept Name";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel6.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(46, 159);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(182, 28);
            this.gunaLabel6.TabIndex = 72;
            this.gunaLabel6.Text = "Faculty Name";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Viner Hand ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(259, 75);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(312, 45);
            this.gunaLabel2.TabIndex = 71;
            this.gunaLabel2.Text = "Discovering Knowledge";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(238, 22);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(343, 45);
            this.gunaLabel1.TabIndex = 70;
            this.gunaLabel1.Text = "RK UNIVERSITY";
            // 
            // Faculty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1224, 816);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Faculty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Faculty";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Faculty_DGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaButton btn_logout;
        private Guna.UI.WinForms.GunaButton btn_campus;
        private Guna.UI.WinForms.GunaButton btn_salary;
        private Guna.UI.WinForms.GunaButton btn_fees;
        private Guna.UI.WinForms.GunaButton btn_course;
        private Guna.UI.WinForms.GunaButton btn_faculty;
        private Guna.UI.WinForms.GunaButton btn_department;
        private Guna.UI.WinForms.GunaButton Btn_student;
        private Guna.UI.WinForms.GunaButton Btn_Home;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel lblcampus;
        private Guna.UI.WinForms.GunaLabel lblsalary;
        private Guna.UI.WinForms.GunaLabel lblfees;
        private Guna.UI.WinForms.GunaLabel lblcourse;
        private Guna.UI.WinForms.GunaLabel lblfaculty;
        private Guna.UI.WinForms.GunaLabel lblstudent;
        private Guna.UI.WinForms.GunaLabel lblhome;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaTextBox ExperienceTb;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaComboBox QualificationCb;
        private Guna.UI.WinForms.GunaLabel gunaLabel11;
        private Guna.UI.WinForms.GunaComboBox F_DeptIdCb;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaComboBox F_GenderCb;
        private Guna.UI.WinForms.GunaTextBox F_AddressTb;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaButton faculty_exit;
        private Guna.UI.WinForms.GunaDataGridView Faculty_DGV;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaButton faculty_delete;
        private Guna.UI.WinForms.GunaButton faculty_edit;
        private Guna.UI.WinForms.GunaButton faculty_save;
        private System.Windows.Forms.DateTimePicker F_DOBdt;
        private Guna.UI.WinForms.GunaTextBox F_SalaryTb;
        private Guna.UI.WinForms.GunaTextBox F_DeptTb;
        private Guna.UI.WinForms.GunaTextBox F_NameTb;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
    }
}