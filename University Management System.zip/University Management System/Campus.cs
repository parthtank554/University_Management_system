﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Campus : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        int Key = 0;
        public Campus()
        {
            InitializeComponent();
            display();
        }
        public void display()
        {
            DataTable data = new DataTable();
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from CampusTbl", con);
            adapt.Fill(data);
            Camp_DGV.DataSource = data;
            con.Close();
        }
        public void edit_record()
        {
            if (Camp_NameTb.Text == "" || Camp_CityTb.Text == "" || Camp_DirTb.Text == "" || Dir_RankTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                cmd = new SqlCommand("Update CampusTbl Set Name=@CN,City=@City,Director=@Dir,Rank=@Rank,Join_Date=@Date where Camp_Id=@CKey", con);
                cmd.Parameters.AddWithValue("@CN", Camp_NameTb.Text);
                cmd.Parameters.AddWithValue("@City", Camp_CityTb.Text);
                cmd.Parameters.AddWithValue("@Dir", Camp_DirTb.Text);
                cmd.Parameters.AddWithValue("@Rank", Dir_RankTb.Text);
                cmd.Parameters.AddWithValue("@Date", Camp_DateDt.Value.Date);
                cmd.Parameters.AddWithValue("@CKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Campus Updated");
                Db.ShowDialog();
                con.Close();
                display();
                reset();
            }
        }
        public void Delete()
        {
            if (Key == 0)
            {
                MessageBox.Show("Select The Campus...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from CampusTbl where Camp_Id=@CKey", con);
                cmd.Parameters.AddWithValue("@CKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Campus Deleted");
                Db.ShowDialog();
                con.Close();
                display();
                reset();
            }
        }
        public void reset()
        {
            Camp_NameTb.Text = " ";
            Camp_CityTb.Text = "";
            Camp_DirTb.Text = "";
            Dir_RankTb.Text = "";

        }
        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();

        }

        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void cmp_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cmp_btn_save_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into CampusTbl(Name,City,Director,Rank,Join_Date)values(@CN,@City,@Dir,@Rank,@Date)", con);
            cmd.Parameters.AddWithValue("@CN", Camp_NameTb.Text);
            cmd.Parameters.AddWithValue("@City", Camp_CityTb.Text);
            cmd.Parameters.AddWithValue("@Dir", Camp_DirTb.Text);
            cmd.Parameters.AddWithValue("@Rank", Dir_RankTb.Text);
            cmd.Parameters.AddWithValue("@Date", Camp_DateDt.Value.Date);
            cmd.ExecuteNonQuery();
            DialogBox Db = new DialogBox("Campus Added");
            Db.ShowDialog();
            con.Close();
            display();
            reset();
        }

        private void Camp_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Camp_NameTb.Text = Camp_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            Camp_CityTb.Text = Camp_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            Camp_DirTb.Text = Camp_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            Dir_RankTb.Text = Camp_DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            Camp_DateDt.Text = Camp_DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            if (Camp_NameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(Camp_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        private void cmp_edit_Click(object sender, EventArgs e)
        {
            edit_record();
        }

        private void cmp_delete_Click(object sender, EventArgs e)
        {
            Delete();
        }
    }
}
