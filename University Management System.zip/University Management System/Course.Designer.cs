﻿
namespace University_Management_System
{
    partial class Course
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_logout = new Guna.UI.WinForms.GunaButton();
            this.btn_campus = new Guna.UI.WinForms.GunaButton();
            this.btn_salary = new Guna.UI.WinForms.GunaButton();
            this.btn_fees = new Guna.UI.WinForms.GunaButton();
            this.btn_course = new Guna.UI.WinForms.GunaButton();
            this.btn_faculty = new Guna.UI.WinForms.GunaButton();
            this.btn_department = new Guna.UI.WinForms.GunaButton();
            this.Btn_student = new Guna.UI.WinForms.GunaButton();
            this.Btn_Home = new Guna.UI.WinForms.GunaButton();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.lblcampus = new Guna.UI.WinForms.GunaLabel();
            this.lblsalary = new Guna.UI.WinForms.GunaLabel();
            this.lblfees = new Guna.UI.WinForms.GunaLabel();
            this.lblcourse = new Guna.UI.WinForms.GunaLabel();
            this.lblfaculty = new Guna.UI.WinForms.GunaLabel();
            this.lblstudent = new Guna.UI.WinForms.GunaLabel();
            this.lblhome = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.C_FacIdCb = new Guna.UI.WinForms.GunaComboBox();
            this.C_DeptIdCb = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.course_exit = new Guna.UI.WinForms.GunaButton();
            this.Course_DGV = new Guna.UI.WinForms.GunaDataGridView();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.Course_delete = new Guna.UI.WinForms.GunaButton();
            this.Course_edit = new Guna.UI.WinForms.GunaButton();
            this.course_save = new Guna.UI.WinForms.GunaButton();
            this.C_FNameTb = new Guna.UI.WinForms.GunaTextBox();
            this.C_DeptNameTb = new Guna.UI.WinForms.GunaTextBox();
            this.CreditHrsTb = new Guna.UI.WinForms.GunaTextBox();
            this.CNameTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Course_DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_logout
            // 
            this.btn_logout.AnimationHoverSpeed = 0.07F;
            this.btn_logout.AnimationSpeed = 0.03F;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.BaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.BorderColor = System.Drawing.Color.Black;
            this.btn_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_logout.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Black;
            this.btn_logout.Image = null;
            this.btn_logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_logout.Location = new System.Drawing.Point(111, 740);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_logout.OnHoverImage = null;
            this.btn_logout.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_logout.Radius = 8;
            this.btn_logout.Size = new System.Drawing.Size(160, 42);
            this.btn_logout.TabIndex = 46;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_campus
            // 
            this.btn_campus.AnimationHoverSpeed = 0.07F;
            this.btn_campus.AnimationSpeed = 0.03F;
            this.btn_campus.BackColor = System.Drawing.Color.Transparent;
            this.btn_campus.BaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.BorderColor = System.Drawing.Color.Black;
            this.btn_campus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_campus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_campus.ForeColor = System.Drawing.Color.Black;
            this.btn_campus.Image = null;
            this.btn_campus.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_campus.Location = new System.Drawing.Point(111, 663);
            this.btn_campus.Name = "btn_campus";
            this.btn_campus.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_campus.OnHoverImage = null;
            this.btn_campus.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_campus.Radius = 8;
            this.btn_campus.Size = new System.Drawing.Size(160, 42);
            this.btn_campus.TabIndex = 45;
            this.btn_campus.Text = "Campus";
            this.btn_campus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.Click += new System.EventHandler(this.btn_campus_Click);
            // 
            // btn_salary
            // 
            this.btn_salary.AnimationHoverSpeed = 0.07F;
            this.btn_salary.AnimationSpeed = 0.03F;
            this.btn_salary.BackColor = System.Drawing.Color.Transparent;
            this.btn_salary.BaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.BorderColor = System.Drawing.Color.Black;
            this.btn_salary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_salary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary.ForeColor = System.Drawing.Color.Black;
            this.btn_salary.Image = null;
            this.btn_salary.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_salary.Location = new System.Drawing.Point(111, 587);
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_salary.OnHoverImage = null;
            this.btn_salary.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_salary.Radius = 8;
            this.btn_salary.Size = new System.Drawing.Size(160, 42);
            this.btn_salary.TabIndex = 44;
            this.btn_salary.Text = "Salary";
            this.btn_salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_fees
            // 
            this.btn_fees.AnimationHoverSpeed = 0.07F;
            this.btn_fees.AnimationSpeed = 0.03F;
            this.btn_fees.BackColor = System.Drawing.Color.Transparent;
            this.btn_fees.BaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.BorderColor = System.Drawing.Color.Black;
            this.btn_fees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fees.ForeColor = System.Drawing.Color.Black;
            this.btn_fees.Image = null;
            this.btn_fees.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_fees.Location = new System.Drawing.Point(111, 501);
            this.btn_fees.Name = "btn_fees";
            this.btn_fees.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_fees.OnHoverImage = null;
            this.btn_fees.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_fees.Radius = 8;
            this.btn_fees.Size = new System.Drawing.Size(160, 42);
            this.btn_fees.TabIndex = 43;
            this.btn_fees.Text = "Fees";
            this.btn_fees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.Click += new System.EventHandler(this.btn_fees_Click);
            // 
            // btn_course
            // 
            this.btn_course.AnimationHoverSpeed = 0.07F;
            this.btn_course.AnimationSpeed = 0.03F;
            this.btn_course.BackColor = System.Drawing.Color.Transparent;
            this.btn_course.BaseColor = System.Drawing.Color.Transparent;
            this.btn_course.BorderColor = System.Drawing.Color.Black;
            this.btn_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_course.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_course.ForeColor = System.Drawing.Color.Black;
            this.btn_course.Image = null;
            this.btn_course.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_course.Location = new System.Drawing.Point(123, 426);
            this.btn_course.Name = "btn_course";
            this.btn_course.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_course.OnHoverImage = null;
            this.btn_course.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_course.Radius = 8;
            this.btn_course.Size = new System.Drawing.Size(160, 42);
            this.btn_course.TabIndex = 42;
            this.btn_course.Text = "Courses";
            this.btn_course.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.Click += new System.EventHandler(this.btn_course_Click);
            // 
            // btn_faculty
            // 
            this.btn_faculty.AnimationHoverSpeed = 0.07F;
            this.btn_faculty.AnimationSpeed = 0.03F;
            this.btn_faculty.BackColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BorderColor = System.Drawing.Color.Black;
            this.btn_faculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_faculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_faculty.ForeColor = System.Drawing.Color.Black;
            this.btn_faculty.Image = null;
            this.btn_faculty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_faculty.Location = new System.Drawing.Point(123, 344);
            this.btn_faculty.Name = "btn_faculty";
            this.btn_faculty.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_faculty.OnHoverImage = null;
            this.btn_faculty.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_faculty.Radius = 8;
            this.btn_faculty.Size = new System.Drawing.Size(160, 42);
            this.btn_faculty.TabIndex = 41;
            this.btn_faculty.Text = "Faculty";
            this.btn_faculty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.Click += new System.EventHandler(this.btn_faculty_Click);
            // 
            // btn_department
            // 
            this.btn_department.AnimationHoverSpeed = 0.07F;
            this.btn_department.AnimationSpeed = 0.03F;
            this.btn_department.BackColor = System.Drawing.Color.Transparent;
            this.btn_department.BaseColor = System.Drawing.Color.Transparent;
            this.btn_department.BorderColor = System.Drawing.Color.Black;
            this.btn_department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_department.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_department.ForeColor = System.Drawing.Color.Black;
            this.btn_department.Image = null;
            this.btn_department.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_department.Location = new System.Drawing.Point(123, 268);
            this.btn_department.Name = "btn_department";
            this.btn_department.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_department.OnHoverImage = null;
            this.btn_department.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_department.Radius = 8;
            this.btn_department.Size = new System.Drawing.Size(160, 42);
            this.btn_department.TabIndex = 40;
            this.btn_department.Text = "Department";
            this.btn_department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.Click += new System.EventHandler(this.btn_department_Click);
            // 
            // Btn_student
            // 
            this.Btn_student.AnimationHoverSpeed = 0.07F;
            this.Btn_student.AnimationSpeed = 0.03F;
            this.Btn_student.BackColor = System.Drawing.Color.Transparent;
            this.Btn_student.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.BorderColor = System.Drawing.Color.Black;
            this.Btn_student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_student.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_student.ForeColor = System.Drawing.Color.Black;
            this.Btn_student.Image = null;
            this.Btn_student.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_student.Location = new System.Drawing.Point(111, 182);
            this.Btn_student.Name = "Btn_student";
            this.Btn_student.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_student.OnHoverImage = null;
            this.Btn_student.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_student.Radius = 8;
            this.Btn_student.Size = new System.Drawing.Size(160, 42);
            this.Btn_student.TabIndex = 39;
            this.Btn_student.Text = "Student";
            this.Btn_student.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.Click += new System.EventHandler(this.Btn_student_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.AnimationHoverSpeed = 0.07F;
            this.Btn_Home.AnimationSpeed = 0.03F;
            this.Btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BorderColor = System.Drawing.Color.Black;
            this.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Home.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Home.ForeColor = System.Drawing.Color.Black;
            this.Btn_Home.Image = null;
            this.Btn_Home.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_Home.Location = new System.Drawing.Point(111, 115);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_Home.OnHoverImage = null;
            this.Btn_Home.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_Home.Radius = 8;
            this.Btn_Home.Size = new System.Drawing.Size(160, 42);
            this.Btn_Home.TabIndex = 38;
            this.Btn_Home.Text = "Home";
            this.Btn_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.gunaPanel1.Controls.Add(this.btn_logout);
            this.gunaPanel1.Controls.Add(this.btn_campus);
            this.gunaPanel1.Controls.Add(this.btn_salary);
            this.gunaPanel1.Controls.Add(this.btn_fees);
            this.gunaPanel1.Controls.Add(this.btn_course);
            this.gunaPanel1.Controls.Add(this.btn_faculty);
            this.gunaPanel1.Controls.Add(this.btn_department);
            this.gunaPanel1.Controls.Add(this.Btn_student);
            this.gunaPanel1.Controls.Add(this.Btn_Home);
            this.gunaPanel1.Controls.Add(this.lblcampus);
            this.gunaPanel1.Controls.Add(this.lblsalary);
            this.gunaPanel1.Controls.Add(this.lblfees);
            this.gunaPanel1.Controls.Add(this.lblcourse);
            this.gunaPanel1.Controls.Add(this.lblfaculty);
            this.gunaPanel1.Controls.Add(this.lblstudent);
            this.gunaPanel1.Controls.Add(this.lblhome);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox8);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox7);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel1.Location = new System.Drawing.Point(-8, -15);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(302, 792);
            this.gunaPanel1.TabIndex = 1;
            // 
            // lblcampus
            // 
            this.lblcampus.AutoSize = true;
            this.lblcampus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcampus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcampus.Location = new System.Drawing.Point(131, 668);
            this.lblcampus.Name = "lblcampus";
            this.lblcampus.Size = new System.Drawing.Size(95, 26);
            this.lblcampus.TabIndex = 18;
            this.lblcampus.Text = "Campus";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblsalary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(131, 587);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(79, 26);
            this.lblsalary.TabIndex = 17;
            this.lblsalary.Text = "Salary";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfees.Location = new System.Drawing.Point(131, 504);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(58, 26);
            this.lblfees.TabIndex = 16;
            this.lblfees.Text = "Fees";
            this.lblfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcourse.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourse.Location = new System.Drawing.Point(131, 426);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(85, 26);
            this.lblcourse.TabIndex = 15;
            this.lblcourse.Text = "Course";
            // 
            // lblfaculty
            // 
            this.lblfaculty.AutoSize = true;
            this.lblfaculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfaculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfaculty.Location = new System.Drawing.Point(131, 346);
            this.lblfaculty.Name = "lblfaculty";
            this.lblfaculty.Size = new System.Drawing.Size(90, 26);
            this.lblfaculty.TabIndex = 14;
            this.lblfaculty.Text = "Faculty";
            // 
            // lblstudent
            // 
            this.lblstudent.AutoSize = true;
            this.lblstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblstudent.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudent.Location = new System.Drawing.Point(131, 191);
            this.lblstudent.Name = "lblstudent";
            this.lblstudent.Size = new System.Drawing.Size(91, 26);
            this.lblstudent.TabIndex = 12;
            this.lblstudent.Text = "Student";
            // 
            // lblhome
            // 
            this.lblhome.AutoSize = true;
            this.lblhome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblhome.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhome.Location = new System.Drawing.Point(131, 118);
            this.lblhome.Name = "lblhome";
            this.lblhome.Size = new System.Drawing.Size(73, 26);
            this.lblhome.TabIndex = 11;
            this.lblhome.Text = "Home";
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Image = global::University_Management_System.Properties.Resources.logout;
            this.gunaPictureBox10.Location = new System.Drawing.Point(44, 734);
            this.gunaPictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 9;
            this.gunaPictureBox10.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::University_Management_System.Properties.Resources.campus;
            this.gunaPictureBox9.Location = new System.Drawing.Point(44, 653);
            this.gunaPictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 8;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::University_Management_System.Properties.Resources.salary;
            this.gunaPictureBox8.Location = new System.Drawing.Point(44, 578);
            this.gunaPictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 7;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::University_Management_System.Properties.Resources.fees;
            this.gunaPictureBox7.Location = new System.Drawing.Point(44, 495);
            this.gunaPictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 6;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::University_Management_System.Properties.Resources.course;
            this.gunaPictureBox6.Location = new System.Drawing.Point(44, 417);
            this.gunaPictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 5;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::University_Management_System.Properties.Resources.faculty;
            this.gunaPictureBox5.Location = new System.Drawing.Point(44, 334);
            this.gunaPictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::University_Management_System.Properties.Resources.Department;
            this.gunaPictureBox4.Location = new System.Drawing.Point(44, 258);
            this.gunaPictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.student;
            this.gunaPictureBox3.Location = new System.Drawing.Point(44, 181);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.home;
            this.gunaPictureBox2.Location = new System.Drawing.Point(44, 109);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.university;
            this.gunaPictureBox1.Location = new System.Drawing.Point(123, 24);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(73, 60);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.White;
            this.gunaPanel2.Controls.Add(this.C_FacIdCb);
            this.gunaPanel2.Controls.Add(this.C_DeptIdCb);
            this.gunaPanel2.Controls.Add(this.gunaLabel8);
            this.gunaPanel2.Controls.Add(this.course_exit);
            this.gunaPanel2.Controls.Add(this.Course_DGV);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.Course_delete);
            this.gunaPanel2.Controls.Add(this.Course_edit);
            this.gunaPanel2.Controls.Add(this.course_save);
            this.gunaPanel2.Controls.Add(this.C_FNameTb);
            this.gunaPanel2.Controls.Add(this.C_DeptNameTb);
            this.gunaPanel2.Controls.Add(this.CreditHrsTb);
            this.gunaPanel2.Controls.Add(this.CNameTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel7);
            this.gunaPanel2.Controls.Add(this.gunaLabel5);
            this.gunaPanel2.Controls.Add(this.gunaLabel4);
            this.gunaPanel2.Controls.Add(this.gunaLabel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel6);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Location = new System.Drawing.Point(296, -3);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(934, 792);
            this.gunaPanel2.TabIndex = 21;
            // 
            // C_FacIdCb
            // 
            this.C_FacIdCb.BackColor = System.Drawing.Color.Transparent;
            this.C_FacIdCb.BaseColor = System.Drawing.Color.White;
            this.C_FacIdCb.BorderColor = System.Drawing.Color.Silver;
            this.C_FacIdCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.C_FacIdCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C_FacIdCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.C_FacIdCb.ForeColor = System.Drawing.Color.Black;
            this.C_FacIdCb.FormattingEnabled = true;
            this.C_FacIdCb.Location = new System.Drawing.Point(318, 318);
            this.C_FacIdCb.Margin = new System.Windows.Forms.Padding(4);
            this.C_FacIdCb.Name = "C_FacIdCb";
            this.C_FacIdCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.C_FacIdCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.C_FacIdCb.Radius = 5;
            this.C_FacIdCb.Size = new System.Drawing.Size(148, 31);
            this.C_FacIdCb.TabIndex = 69;
            this.C_FacIdCb.SelectionChangeCommitted += new System.EventHandler(this.C_FacIdCb_SelectionChangeCommitted);
            // 
            // C_DeptIdCb
            // 
            this.C_DeptIdCb.BackColor = System.Drawing.Color.Transparent;
            this.C_DeptIdCb.BaseColor = System.Drawing.Color.White;
            this.C_DeptIdCb.BorderColor = System.Drawing.Color.Silver;
            this.C_DeptIdCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.C_DeptIdCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.C_DeptIdCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.C_DeptIdCb.ForeColor = System.Drawing.Color.Black;
            this.C_DeptIdCb.FormattingEnabled = true;
            this.C_DeptIdCb.Location = new System.Drawing.Point(578, 208);
            this.C_DeptIdCb.Margin = new System.Windows.Forms.Padding(4);
            this.C_DeptIdCb.Name = "C_DeptIdCb";
            this.C_DeptIdCb.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.C_DeptIdCb.OnHoverItemForeColor = System.Drawing.Color.White;
            this.C_DeptIdCb.Radius = 5;
            this.C_DeptIdCb.Size = new System.Drawing.Size(148, 31);
            this.C_DeptIdCb.TabIndex = 68;
            this.C_DeptIdCb.SelectionChangeCommitted += new System.EventHandler(this.C_DeptIdCb_SelectionChangeCommitted);
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel8.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(312, 282);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(137, 28);
            this.gunaLabel8.TabIndex = 67;
            this.gunaLabel8.Text = "Faculty Id";
            // 
            // course_exit
            // 
            this.course_exit.AnimationHoverSpeed = 0.07F;
            this.course_exit.AnimationSpeed = 0.03F;
            this.course_exit.BaseColor = System.Drawing.Color.Transparent;
            this.course_exit.BorderColor = System.Drawing.Color.Black;
            this.course_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.course_exit.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course_exit.ForeColor = System.Drawing.Color.Red;
            this.course_exit.Image = null;
            this.course_exit.ImageSize = new System.Drawing.Size(20, 20);
            this.course_exit.Location = new System.Drawing.Point(845, 25);
            this.course_exit.Name = "course_exit";
            this.course_exit.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.course_exit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.course_exit.OnHoverForeColor = System.Drawing.Color.Red;
            this.course_exit.OnHoverImage = null;
            this.course_exit.OnPressedColor = System.Drawing.Color.Black;
            this.course_exit.Size = new System.Drawing.Size(45, 42);
            this.course_exit.TabIndex = 50;
            this.course_exit.Text = "X";
            this.course_exit.Click += new System.EventHandler(this.course_exit_Click);
            // 
            // Course_DGV
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.Course_DGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.Course_DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Course_DGV.BackgroundColor = System.Drawing.Color.White;
            this.Course_DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Course_DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Course_DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Course_DGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.Course_DGV.ColumnHeadersHeight = 4;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Course_DGV.DefaultCellStyle = dataGridViewCellStyle9;
            this.Course_DGV.EnableHeadersVisualStyles = false;
            this.Course_DGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Course_DGV.Location = new System.Drawing.Point(4, 469);
            this.Course_DGV.Margin = new System.Windows.Forms.Padding(4);
            this.Course_DGV.Name = "Course_DGV";
            this.Course_DGV.RowHeadersVisible = false;
            this.Course_DGV.RowHeadersWidth = 51;
            this.Course_DGV.RowTemplate.Height = 24;
            this.Course_DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Course_DGV.Size = new System.Drawing.Size(904, 312);
            this.Course_DGV.TabIndex = 66;
            this.Course_DGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.Course_DGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Course_DGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Course_DGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Course_DGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Course_DGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Course_DGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Course_DGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Course_DGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Course_DGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Course_DGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Course_DGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Course_DGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Course_DGV.ThemeStyle.HeaderStyle.Height = 4;
            this.Course_DGV.ThemeStyle.ReadOnly = false;
            this.Course_DGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Course_DGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Course_DGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Course_DGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Course_DGV.ThemeStyle.RowsStyle.Height = 24;
            this.Course_DGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Course_DGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Course_DGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Course_DGV_CellContentClick);
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPanel3.Location = new System.Drawing.Point(-6, 460);
            this.gunaPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(1041, 6);
            this.gunaPanel3.TabIndex = 65;
            // 
            // Course_delete
            // 
            this.Course_delete.AnimationHoverSpeed = 0.07F;
            this.Course_delete.AnimationSpeed = 0.03F;
            this.Course_delete.BackColor = System.Drawing.Color.Transparent;
            this.Course_delete.BaseColor = System.Drawing.Color.Transparent;
            this.Course_delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.Course_delete.BorderSize = 2;
            this.Course_delete.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Course_delete.ForeColor = System.Drawing.Color.Black;
            this.Course_delete.Image = null;
            this.Course_delete.ImageSize = new System.Drawing.Size(20, 20);
            this.Course_delete.Location = new System.Drawing.Point(529, 396);
            this.Course_delete.Margin = new System.Windows.Forms.Padding(4);
            this.Course_delete.Name = "Course_delete";
            this.Course_delete.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.Course_delete.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Course_delete.OnHoverForeColor = System.Drawing.Color.White;
            this.Course_delete.OnHoverImage = null;
            this.Course_delete.OnPressedColor = System.Drawing.Color.Black;
            this.Course_delete.Radius = 8;
            this.Course_delete.Size = new System.Drawing.Size(132, 53);
            this.Course_delete.TabIndex = 64;
            this.Course_delete.Text = "Delete";
            this.Course_delete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Course_delete.Click += new System.EventHandler(this.Course_delete_Click);
            // 
            // Course_edit
            // 
            this.Course_edit.AnimationHoverSpeed = 0.07F;
            this.Course_edit.AnimationSpeed = 0.03F;
            this.Course_edit.BackColor = System.Drawing.Color.Transparent;
            this.Course_edit.BaseColor = System.Drawing.Color.Transparent;
            this.Course_edit.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.Course_edit.BorderSize = 2;
            this.Course_edit.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Course_edit.ForeColor = System.Drawing.Color.Black;
            this.Course_edit.Image = null;
            this.Course_edit.ImageSize = new System.Drawing.Size(20, 20);
            this.Course_edit.Location = new System.Drawing.Point(307, 396);
            this.Course_edit.Margin = new System.Windows.Forms.Padding(4);
            this.Course_edit.Name = "Course_edit";
            this.Course_edit.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.Course_edit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Course_edit.OnHoverForeColor = System.Drawing.Color.White;
            this.Course_edit.OnHoverImage = null;
            this.Course_edit.OnPressedColor = System.Drawing.Color.Black;
            this.Course_edit.Radius = 8;
            this.Course_edit.Size = new System.Drawing.Size(132, 53);
            this.Course_edit.TabIndex = 63;
            this.Course_edit.Text = "Edit";
            this.Course_edit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Course_edit.Click += new System.EventHandler(this.Course_edit_Click);
            // 
            // course_save
            // 
            this.course_save.AnimationHoverSpeed = 0.07F;
            this.course_save.AnimationSpeed = 0.03F;
            this.course_save.BackColor = System.Drawing.Color.Transparent;
            this.course_save.BaseColor = System.Drawing.Color.Transparent;
            this.course_save.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.course_save.BorderSize = 2;
            this.course_save.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course_save.ForeColor = System.Drawing.Color.Black;
            this.course_save.Image = null;
            this.course_save.ImageSize = new System.Drawing.Size(20, 20);
            this.course_save.Location = new System.Drawing.Point(92, 396);
            this.course_save.Margin = new System.Windows.Forms.Padding(4);
            this.course_save.Name = "course_save";
            this.course_save.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.course_save.OnHoverBorderColor = System.Drawing.Color.Black;
            this.course_save.OnHoverForeColor = System.Drawing.Color.White;
            this.course_save.OnHoverImage = null;
            this.course_save.OnPressedColor = System.Drawing.Color.Black;
            this.course_save.Radius = 8;
            this.course_save.Size = new System.Drawing.Size(132, 53);
            this.course_save.TabIndex = 62;
            this.course_save.Text = "Save";
            this.course_save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.course_save.Click += new System.EventHandler(this.course_save_Click);
            // 
            // C_FNameTb
            // 
            this.C_FNameTb.BaseColor = System.Drawing.Color.White;
            this.C_FNameTb.BorderColor = System.Drawing.Color.Silver;
            this.C_FNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.C_FNameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.C_FNameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.C_FNameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.C_FNameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.C_FNameTb.Location = new System.Drawing.Point(579, 317);
            this.C_FNameTb.Margin = new System.Windows.Forms.Padding(4);
            this.C_FNameTb.Name = "C_FNameTb";
            this.C_FNameTb.PasswordChar = '\0';
            this.C_FNameTb.Radius = 5;
            this.C_FNameTb.Size = new System.Drawing.Size(205, 32);
            this.C_FNameTb.TabIndex = 61;
            // 
            // C_DeptNameTb
            // 
            this.C_DeptNameTb.BaseColor = System.Drawing.Color.White;
            this.C_DeptNameTb.BorderColor = System.Drawing.Color.Silver;
            this.C_DeptNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.C_DeptNameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.C_DeptNameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.C_DeptNameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.C_DeptNameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.C_DeptNameTb.Location = new System.Drawing.Point(45, 317);
            this.C_DeptNameTb.Margin = new System.Windows.Forms.Padding(4);
            this.C_DeptNameTb.Name = "C_DeptNameTb";
            this.C_DeptNameTb.PasswordChar = '\0';
            this.C_DeptNameTb.Radius = 5;
            this.C_DeptNameTb.Size = new System.Drawing.Size(205, 32);
            this.C_DeptNameTb.TabIndex = 60;
            // 
            // CreditHrsTb
            // 
            this.CreditHrsTb.BaseColor = System.Drawing.Color.White;
            this.CreditHrsTb.BorderColor = System.Drawing.Color.Silver;
            this.CreditHrsTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreditHrsTb.FocusedBaseColor = System.Drawing.Color.White;
            this.CreditHrsTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.CreditHrsTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.CreditHrsTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CreditHrsTb.Location = new System.Drawing.Point(307, 205);
            this.CreditHrsTb.Margin = new System.Windows.Forms.Padding(4);
            this.CreditHrsTb.Name = "CreditHrsTb";
            this.CreditHrsTb.PasswordChar = '\0';
            this.CreditHrsTb.Radius = 5;
            this.CreditHrsTb.Size = new System.Drawing.Size(205, 32);
            this.CreditHrsTb.TabIndex = 59;
            // 
            // CNameTb
            // 
            this.CNameTb.BaseColor = System.Drawing.Color.White;
            this.CNameTb.BorderColor = System.Drawing.Color.Silver;
            this.CNameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CNameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.CNameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.CNameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.CNameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CNameTb.Location = new System.Drawing.Point(45, 205);
            this.CNameTb.Margin = new System.Windows.Forms.Padding(4);
            this.CNameTb.Name = "CNameTb";
            this.CNameTb.PasswordChar = '\0';
            this.CNameTb.Radius = 5;
            this.CNameTb.Size = new System.Drawing.Size(205, 32);
            this.CNameTb.TabIndex = 58;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel7.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(572, 282);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(182, 28);
            this.gunaLabel7.TabIndex = 57;
            this.gunaLabel7.Text = "Faculty Name";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel5.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(572, 165);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(106, 28);
            this.gunaLabel5.TabIndex = 56;
            this.gunaLabel5.Text = "Dept Id";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel4.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(39, 282);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(176, 28);
            this.gunaLabel4.TabIndex = 55;
            this.gunaLabel4.Text = "Depart Name";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel3.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(301, 165);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(188, 28);
            this.gunaLabel3.TabIndex = 54;
            this.gunaLabel3.Text = "Credit Hourse";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel6.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(39, 165);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(179, 28);
            this.gunaLabel6.TabIndex = 53;
            this.gunaLabel6.Text = "Course Name";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Viner Hand ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(252, 81);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(312, 45);
            this.gunaLabel2.TabIndex = 52;
            this.gunaLabel2.Text = "Discovering Knowledge";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(231, 28);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(343, 45);
            this.gunaLabel1.TabIndex = 51;
            this.gunaLabel1.Text = "RK UNIVERSITY";
            // 
            // Course
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 787);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Course";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Course";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Course_DGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaButton btn_logout;
        private Guna.UI.WinForms.GunaButton btn_campus;
        private Guna.UI.WinForms.GunaButton btn_salary;
        private Guna.UI.WinForms.GunaButton btn_fees;
        private Guna.UI.WinForms.GunaButton btn_course;
        private Guna.UI.WinForms.GunaButton btn_faculty;
        private Guna.UI.WinForms.GunaButton btn_department;
        private Guna.UI.WinForms.GunaButton Btn_student;
        private Guna.UI.WinForms.GunaButton Btn_Home;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel lblcampus;
        private Guna.UI.WinForms.GunaLabel lblsalary;
        private Guna.UI.WinForms.GunaLabel lblfees;
        private Guna.UI.WinForms.GunaLabel lblcourse;
        private Guna.UI.WinForms.GunaLabel lblfaculty;
        private Guna.UI.WinForms.GunaLabel lblstudent;
        private Guna.UI.WinForms.GunaLabel lblhome;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaComboBox C_FacIdCb;
        private Guna.UI.WinForms.GunaComboBox C_DeptIdCb;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaButton course_exit;
        private Guna.UI.WinForms.GunaDataGridView Course_DGV;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaButton Course_delete;
        private Guna.UI.WinForms.GunaButton Course_edit;
        private Guna.UI.WinForms.GunaButton course_save;
        private Guna.UI.WinForms.GunaTextBox C_FNameTb;
        private Guna.UI.WinForms.GunaTextBox C_DeptNameTb;
        private Guna.UI.WinForms.GunaTextBox CreditHrsTb;
        private Guna.UI.WinForms.GunaTextBox CNameTb;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
    }
}