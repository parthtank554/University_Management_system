﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Student : Form
    {
        SqlConnection Connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;

        public Student()
        {
            InitializeComponent();
            Display();
            GetDeptId();
        }

        private void GetDeptId()
        {
            Connection.Open();
            SqlCommand cmd = new SqlCommand("Select DeptId from Department_Tbl", Connection);
            SqlDataReader Reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Columns.Add("DeptId", typeof(int));
            data.Load(Reader);
            St_DeptIdCb.ValueMember = "DeptId";
            St_DeptIdCb.DataSource = data;
            Connection.Close();
        }
        private void GetDeptName()
        {
            Connection.Open();
            string Query = "Select * from Department_Tbl where DeptId = " + St_DeptIdCb.SelectedValue.ToString() + " ";
            SqlCommand cmd = new SqlCommand(Query, Connection);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                St_DeptTb.Text = dataRow["Name"].ToString();
            }
            Connection.Close();
        }
        private void Display()
        {
            DataTable data = new DataTable();
            Connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from Student_Tbl", Connection);
            adapter.Fill(data);
            Student_DGV.DataSource = data;
            Connection.Close();
        }
        private void Reset()
        {
            StNameTb.Text = "";
            St_PhoneTb.Text = "";
            StAddressTb.Text = "";
            St_DeptTb.Text = "";
            StGenderCb.SelectedIndex = -1;
            St_DeptIdCb.SelectedIndex = -1;
        }
        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }

        private void std_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void student_btn_save_Click(object sender, EventArgs e)
        {
            if (StNameTb.Text == "" || St_PhoneTb.Text == "" || StAddressTb.Text == "" || St_DeptIdCb.SelectedIndex == -1 || St_DeptTb.Text == "" || St_SemesterCb.SelectedIndex == -1 || StGenderCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Insert into Student_Tbl(Name,DOB,Gender,Address,DeptId,Department,Phone,Semester)values(@SN,@SDOB,@SGen,@SAdd,@SDeptId,@SDept,@SPh,@Sem)", Connection);
                cmd.Parameters.AddWithValue("@SN", StNameTb.Text);
                cmd.Parameters.AddWithValue("@SDOB", StDOBdt.Value.Date);
                cmd.Parameters.AddWithValue("@SGen", StGenderCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@SAdd", StAddressTb.Text);
                cmd.Parameters.AddWithValue("@SDeptId", St_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@SDept", St_DeptTb.Text);
                cmd.Parameters.AddWithValue("@SPh", St_PhoneTb.Text);
                cmd.Parameters.AddWithValue("@Sem", St_SemesterCb.SelectedItem.ToString()); ;
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Student Added");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }

        int Key = 0;
        private void St_DeptIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDeptName();
        }

        private void student_btn_delete_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select The Student...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Delete from Student_Tbl where StId=@StKey", Connection);
                cmd.Parameters.AddWithValue("@StKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Student Deleted");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }

        private void Student_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            StNameTb.Text = Student_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            StDOBdt.Text = Student_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            StGenderCb.SelectedItem = Student_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            StAddressTb.Text = Student_DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            St_DeptIdCb.SelectedValue = Student_DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            St_DeptTb.Text = Student_DGV.Rows[e.RowIndex].Cells[6].Value.ToString();
            St_PhoneTb.Text = Student_DGV.Rows[e.RowIndex].Cells[7].Value.ToString();
            St_SemesterCb.SelectedItem = Student_DGV.Rows[e.RowIndex].Cells[8].Value.ToString();
            if (StNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(Student_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        private void student_btn_edit_Click(object sender, EventArgs e)
        {
            if (StNameTb.Text == "" || St_PhoneTb.Text == "" || StAddressTb.Text == "" || St_DeptIdCb.SelectedIndex == -1 || St_DeptTb.Text == "" || St_SemesterCb.SelectedIndex == -1 || StGenderCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Update Student_Tbl Set Name=@SN,DOB=@SDOB,Gender=@SGen,Address=@SAdd,DeptId=@SDeptId,Department=@SDept,Phone=@SPh,Semester=@Sem where StId=@SKey", Connection);
                cmd.Parameters.AddWithValue("@SN", StNameTb.Text);
                cmd.Parameters.AddWithValue("@SDOB", StDOBdt.Value.Date);
                cmd.Parameters.AddWithValue("@SGen", StGenderCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@SAdd", StAddressTb.Text);
                cmd.Parameters.AddWithValue("@SDeptId", St_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@SDept", St_DeptTb.Text);
                cmd.Parameters.AddWithValue("@SPh", St_PhoneTb.Text);
                cmd.Parameters.AddWithValue("@Sem", St_SemesterCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@SKey", Key); ;
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Student Updated");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }
    }
}
