﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Course : Form
    {
        SqlConnection Connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        public Course()
        {
            InitializeComponent();
            GetDeptId();
            GetFacId();
            Display();
        }
        private void GetDeptId()
        {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Select DeptId from Department_Tbl", Connection);
                SqlDataReader Reader = cmd.ExecuteReader();
                DataTable data = new DataTable();
                data.Columns.Add("DeptId");
                data.Load(Reader);
                C_DeptIdCb.ValueMember = "DeptId";
                C_DeptIdCb.DataSource = data;
                Connection.Close();
        }

        private void GetFacId()
        {
            Connection.Open();
            SqlCommand cmd = new SqlCommand("Select F_Id from Faculty_Tbl", Connection);
            SqlDataReader Reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Columns.Add("F_Id");
            data.Load(Reader);
            C_FacIdCb.ValueMember = "F_Id";
            C_FacIdCb.DataSource = data;
            Connection.Close();
        }
        private void GetDeptName()
        {
            Connection.Open();
            string Query = "Select * from Department_Tbl where DeptId = " + C_DeptIdCb.SelectedValue.ToString() + " ";
            SqlCommand cmd = new SqlCommand(Query, Connection);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                C_DeptNameTb.Text = dataRow["Name"].ToString();
            }
            Connection.Close();
        }
        private void GetFacName()
        {
            Connection.Open();
            string Query = "Select * from Faculty_Tbl where F_Id = " + C_FacIdCb.SelectedValue.ToString() + " ";
            SqlCommand cmd = new SqlCommand(Query, Connection);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                C_FNameTb.Text = dataRow["Name"].ToString();
            }
            Connection.Close();
        }
        private void Reset()
        {
            CNameTb.Text = "";
            CreditHrsTb.Text = "";
            C_DeptIdCb.SelectedIndex = -1;
            C_DeptNameTb.Text = "";
            C_FacIdCb.SelectedIndex = -1;
            C_FNameTb.Text = "";
        }
        private void Display()
        {
            DataTable data = new DataTable();
            Connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from Course_Tbl", Connection);
            adapter.Fill(data);
            Course_DGV.DataSource = data;
            Connection.Close();
        }
        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void course_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void course_save_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || CreditHrsTb.Text == "" || C_DeptIdCb.SelectedIndex == -1 || C_DeptNameTb.Text == "" || C_FacIdCb.SelectedIndex == -1 || C_FNameTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Insert into Course_Tbl(Course_Name,Credit_Hrs,DeptId,Department,Fac_Id,Fac_Name)values(@CN,@CH,@DeptId,@DepName,@FacId,@FacName)", Connection);
                cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                cmd.Parameters.AddWithValue("@CH", CreditHrsTb.Text);
                cmd.Parameters.AddWithValue("@DeptId", C_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@DepName", C_DeptNameTb.Text);
                cmd.Parameters.AddWithValue("@FacId", C_FacIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@FacName", C_FNameTb.Text);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Course Added");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }

        private void C_DeptIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDeptName();
        }

        private void C_FacIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetFacName();
        }

        int Key = 0;
        private void Course_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CNameTb.Text = Course_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            CreditHrsTb.Text = Course_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            C_DeptIdCb.SelectedValue = Course_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            C_DeptNameTb.Text = Course_DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            C_FacIdCb.SelectedValue = Course_DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            C_FNameTb.Text = Course_DGV.Rows[e.RowIndex].Cells[6].Value.ToString();
            if (CNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(Course_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        private void Course_edit_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || CreditHrsTb.Text == "" || C_DeptIdCb.SelectedIndex == -1 || C_DeptNameTb.Text == "" || C_FacIdCb.SelectedIndex == -1 || C_FNameTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Update Course_Tbl Set Course_Name=@CN,Credit_Hrs=@CH,DeptId=@DeptId,Department=@Dept,Fac_Id=@FId,Fac_Name=@FN where Course_Id=@CKey", Connection);
                cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                cmd.Parameters.AddWithValue("@CH", CreditHrsTb.Text);
                cmd.Parameters.AddWithValue("@DeptId", C_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@Dept", C_DeptNameTb.Text);
                cmd.Parameters.AddWithValue("@FId", C_FacIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@FN", C_FNameTb.Text); ;
                cmd.Parameters.AddWithValue("@CKey", Key); ;
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Course Updated");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }

        private void Course_delete_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select The Course...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Connection.Open();
                SqlCommand cmd = new SqlCommand("Delete from Course_Tbl where Course_Id=@CKey", Connection);
                cmd.Parameters.AddWithValue("@CKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Course Deleted");
                Db.ShowDialog();
                Connection.Close();
                Display();
                Reset();
            }
        }
    }
}
