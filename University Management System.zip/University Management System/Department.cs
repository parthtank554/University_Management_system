﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace University_Management_System
{
    public partial class Department : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        public Department()
        {
            InitializeComponent();
            Display();
        }
        public void Display()
        {
            DataTable data = new DataTable();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from Department_Tbl", con);
            adapter.Fill(data);
            Dept_DGV.DataSource = data;
            con.Close();
        }
        private void Reset()
        {
            DeptNameTb.Text = "";
            DeptFeesTb.Text = "";
            DeptIntakeTb.Text = "";
        }

        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }
        private void dept_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void dept_save_Click(object sender, EventArgs e)
        {
            if (DeptNameTb.Text == "" || DeptIntakeTb.Text == "" || DeptFeesTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into Department_Tbl(Name,Intake,Fees)values(@DN,@DI,@DF)", con);
                cmd.Parameters.AddWithValue("@DN", DeptNameTb.Text);
                cmd.Parameters.AddWithValue("@DI", DeptIntakeTb.Text);
                cmd.Parameters.AddWithValue("@DF", DeptFeesTb.Text);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Department Added");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }

        }

        int Key = 0;
        private void Dept_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DeptNameTb.Text = Dept_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            DeptIntakeTb.Text = Dept_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            DeptFeesTb.Text = Dept_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (DeptNameTb.Text == "")
            {
                Key = 0;
                DeptNameTb.Text = "";
                DeptFeesTb.Text = "";
                DeptIntakeTb.Text = "";
            }
            else
            {
                Key = int.Parse(Dept_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        private void dept_edit_Click(object sender, EventArgs e)
        {
            if (DeptNameTb.Text == "" || DeptIntakeTb.Text == "" || DeptFeesTb.Text == "")
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Update Department_Tbl Set Name=@DN ,Intake=@DI ,Fees=@DF where DeptId=@DKey", con);
                cmd.Parameters.AddWithValue("@DN", DeptNameTb.Text);
                cmd.Parameters.AddWithValue("@DI", DeptIntakeTb.Text);
                cmd.Parameters.AddWithValue("@DF", DeptFeesTb.Text);
                cmd.Parameters.AddWithValue("@DKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Department Updated");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void dept_delete_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select The Department...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from Department_Tbl where DeptId=@DKey", con);
                cmd.Parameters.AddWithValue("@DKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Department Deleted");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }
    }
}
