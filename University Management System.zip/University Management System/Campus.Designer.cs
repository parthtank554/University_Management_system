﻿
namespace University_Management_System
{
    partial class Campus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.btn_logout = new Guna.UI.WinForms.GunaButton();
            this.btn_campus = new Guna.UI.WinForms.GunaButton();
            this.btn_salary = new Guna.UI.WinForms.GunaButton();
            this.btn_fees = new Guna.UI.WinForms.GunaButton();
            this.btn_course = new Guna.UI.WinForms.GunaButton();
            this.btn_faculty = new Guna.UI.WinForms.GunaButton();
            this.btn_department = new Guna.UI.WinForms.GunaButton();
            this.Btn_student = new Guna.UI.WinForms.GunaButton();
            this.Btn_Home = new Guna.UI.WinForms.GunaButton();
            this.lblcampus = new Guna.UI.WinForms.GunaLabel();
            this.lblsalary = new Guna.UI.WinForms.GunaLabel();
            this.lblfees = new Guna.UI.WinForms.GunaLabel();
            this.lblcourse = new Guna.UI.WinForms.GunaLabel();
            this.lblfaculty = new Guna.UI.WinForms.GunaLabel();
            this.lblstudent = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.cmp_exit = new Guna.UI.WinForms.GunaButton();
            this.Camp_DGV = new Guna.UI.WinForms.GunaDataGridView();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.cmp_btn_save = new Guna.UI.WinForms.GunaButton();
            this.Camp_DateDt = new System.Windows.Forms.DateTimePicker();
            this.Dir_RankTb = new Guna.UI.WinForms.GunaTextBox();
            this.Camp_DirTb = new Guna.UI.WinForms.GunaTextBox();
            this.Camp_CityTb = new Guna.UI.WinForms.GunaTextBox();
            this.Camp_NameTb = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.cmp_edit = new Guna.UI.WinForms.GunaButton();
            this.cmp_delete = new Guna.UI.WinForms.GunaButton();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Camp_DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.LemonChiffon;
            this.gunaPanel1.Controls.Add(this.btn_logout);
            this.gunaPanel1.Controls.Add(this.btn_campus);
            this.gunaPanel1.Controls.Add(this.btn_salary);
            this.gunaPanel1.Controls.Add(this.btn_fees);
            this.gunaPanel1.Controls.Add(this.btn_course);
            this.gunaPanel1.Controls.Add(this.btn_faculty);
            this.gunaPanel1.Controls.Add(this.btn_department);
            this.gunaPanel1.Controls.Add(this.Btn_student);
            this.gunaPanel1.Controls.Add(this.Btn_Home);
            this.gunaPanel1.Controls.Add(this.lblcampus);
            this.gunaPanel1.Controls.Add(this.lblsalary);
            this.gunaPanel1.Controls.Add(this.lblfees);
            this.gunaPanel1.Controls.Add(this.lblcourse);
            this.gunaPanel1.Controls.Add(this.lblfaculty);
            this.gunaPanel1.Controls.Add(this.lblstudent);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox8);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox7);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel1.Location = new System.Drawing.Point(0, -1);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(306, 792);
            this.gunaPanel1.TabIndex = 0;
            // 
            // btn_logout
            // 
            this.btn_logout.AnimationHoverSpeed = 0.07F;
            this.btn_logout.AnimationSpeed = 0.03F;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.BaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.BorderColor = System.Drawing.Color.Black;
            this.btn_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_logout.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.Black;
            this.btn_logout.Image = null;
            this.btn_logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_logout.Location = new System.Drawing.Point(111, 729);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_logout.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_logout.OnHoverImage = null;
            this.btn_logout.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_logout.Radius = 8;
            this.btn_logout.Size = new System.Drawing.Size(160, 42);
            this.btn_logout.TabIndex = 46;
            this.btn_logout.Text = "Logout";
            this.btn_logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_campus
            // 
            this.btn_campus.AnimationHoverSpeed = 0.07F;
            this.btn_campus.AnimationSpeed = 0.03F;
            this.btn_campus.BackColor = System.Drawing.Color.Transparent;
            this.btn_campus.BaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.BorderColor = System.Drawing.Color.Black;
            this.btn_campus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_campus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_campus.ForeColor = System.Drawing.Color.Black;
            this.btn_campus.Image = null;
            this.btn_campus.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_campus.Location = new System.Drawing.Point(111, 652);
            this.btn_campus.Name = "btn_campus";
            this.btn_campus.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_campus.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_campus.OnHoverImage = null;
            this.btn_campus.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_campus.Radius = 8;
            this.btn_campus.Size = new System.Drawing.Size(160, 42);
            this.btn_campus.TabIndex = 45;
            this.btn_campus.Text = "Campus";
            this.btn_campus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_campus.Click += new System.EventHandler(this.btn_campus_Click);
            // 
            // btn_salary
            // 
            this.btn_salary.AnimationHoverSpeed = 0.07F;
            this.btn_salary.AnimationSpeed = 0.03F;
            this.btn_salary.BackColor = System.Drawing.Color.Transparent;
            this.btn_salary.BaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.BorderColor = System.Drawing.Color.Black;
            this.btn_salary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_salary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary.ForeColor = System.Drawing.Color.Black;
            this.btn_salary.Image = null;
            this.btn_salary.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_salary.Location = new System.Drawing.Point(111, 576);
            this.btn_salary.Name = "btn_salary";
            this.btn_salary.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_salary.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_salary.OnHoverImage = null;
            this.btn_salary.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_salary.Radius = 8;
            this.btn_salary.Size = new System.Drawing.Size(160, 42);
            this.btn_salary.TabIndex = 44;
            this.btn_salary.Text = "Salary";
            this.btn_salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_salary.Click += new System.EventHandler(this.btn_salary_Click);
            // 
            // btn_fees
            // 
            this.btn_fees.AnimationHoverSpeed = 0.07F;
            this.btn_fees.AnimationSpeed = 0.03F;
            this.btn_fees.BackColor = System.Drawing.Color.Transparent;
            this.btn_fees.BaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.BorderColor = System.Drawing.Color.Black;
            this.btn_fees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_fees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fees.ForeColor = System.Drawing.Color.Black;
            this.btn_fees.Image = null;
            this.btn_fees.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_fees.Location = new System.Drawing.Point(111, 490);
            this.btn_fees.Name = "btn_fees";
            this.btn_fees.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_fees.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_fees.OnHoverImage = null;
            this.btn_fees.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_fees.Radius = 8;
            this.btn_fees.Size = new System.Drawing.Size(160, 42);
            this.btn_fees.TabIndex = 43;
            this.btn_fees.Text = "Fees";
            this.btn_fees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_fees.Click += new System.EventHandler(this.btn_fees_Click);
            // 
            // btn_course
            // 
            this.btn_course.AnimationHoverSpeed = 0.07F;
            this.btn_course.AnimationSpeed = 0.03F;
            this.btn_course.BackColor = System.Drawing.Color.Transparent;
            this.btn_course.BaseColor = System.Drawing.Color.Transparent;
            this.btn_course.BorderColor = System.Drawing.Color.Black;
            this.btn_course.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_course.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_course.ForeColor = System.Drawing.Color.Black;
            this.btn_course.Image = null;
            this.btn_course.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_course.Location = new System.Drawing.Point(123, 415);
            this.btn_course.Name = "btn_course";
            this.btn_course.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_course.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_course.OnHoverImage = null;
            this.btn_course.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_course.Radius = 8;
            this.btn_course.Size = new System.Drawing.Size(160, 42);
            this.btn_course.TabIndex = 42;
            this.btn_course.Text = "Courses";
            this.btn_course.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_course.Click += new System.EventHandler(this.btn_course_Click);
            // 
            // btn_faculty
            // 
            this.btn_faculty.AnimationHoverSpeed = 0.07F;
            this.btn_faculty.AnimationSpeed = 0.03F;
            this.btn_faculty.BackColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.BorderColor = System.Drawing.Color.Black;
            this.btn_faculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_faculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_faculty.ForeColor = System.Drawing.Color.Black;
            this.btn_faculty.Image = null;
            this.btn_faculty.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_faculty.Location = new System.Drawing.Point(123, 333);
            this.btn_faculty.Name = "btn_faculty";
            this.btn_faculty.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_faculty.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_faculty.OnHoverImage = null;
            this.btn_faculty.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_faculty.Radius = 8;
            this.btn_faculty.Size = new System.Drawing.Size(160, 42);
            this.btn_faculty.TabIndex = 41;
            this.btn_faculty.Text = "Faculty";
            this.btn_faculty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_faculty.Click += new System.EventHandler(this.btn_faculty_Click);
            // 
            // btn_department
            // 
            this.btn_department.AnimationHoverSpeed = 0.07F;
            this.btn_department.AnimationSpeed = 0.03F;
            this.btn_department.BackColor = System.Drawing.Color.Transparent;
            this.btn_department.BaseColor = System.Drawing.Color.Transparent;
            this.btn_department.BorderColor = System.Drawing.Color.Black;
            this.btn_department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_department.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_department.ForeColor = System.Drawing.Color.Black;
            this.btn_department.Image = null;
            this.btn_department.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_department.Location = new System.Drawing.Point(123, 257);
            this.btn_department.Name = "btn_department";
            this.btn_department.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btn_department.OnHoverForeColor = System.Drawing.Color.Black;
            this.btn_department.OnHoverImage = null;
            this.btn_department.OnPressedColor = System.Drawing.Color.Transparent;
            this.btn_department.Radius = 8;
            this.btn_department.Size = new System.Drawing.Size(160, 42);
            this.btn_department.TabIndex = 40;
            this.btn_department.Text = "Department";
            this.btn_department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_department.Click += new System.EventHandler(this.btn_department_Click);
            // 
            // Btn_student
            // 
            this.Btn_student.AnimationHoverSpeed = 0.07F;
            this.Btn_student.AnimationSpeed = 0.03F;
            this.Btn_student.BackColor = System.Drawing.Color.Transparent;
            this.Btn_student.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.BorderColor = System.Drawing.Color.Black;
            this.Btn_student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_student.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_student.ForeColor = System.Drawing.Color.Black;
            this.Btn_student.Image = null;
            this.Btn_student.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_student.Location = new System.Drawing.Point(111, 171);
            this.Btn_student.Name = "Btn_student";
            this.Btn_student.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_student.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_student.OnHoverImage = null;
            this.Btn_student.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_student.Radius = 8;
            this.Btn_student.Size = new System.Drawing.Size(160, 42);
            this.Btn_student.TabIndex = 39;
            this.Btn_student.Text = "Student";
            this.Btn_student.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_student.Click += new System.EventHandler(this.Btn_student_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.AnimationHoverSpeed = 0.07F;
            this.Btn_Home.AnimationSpeed = 0.03F;
            this.Btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.BorderColor = System.Drawing.Color.Black;
            this.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Home.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Home.ForeColor = System.Drawing.Color.Black;
            this.Btn_Home.Image = null;
            this.Btn_Home.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.ImageSize = new System.Drawing.Size(20, 20);
            this.Btn_Home.Location = new System.Drawing.Point(111, 106);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.Btn_Home.OnHoverForeColor = System.Drawing.Color.Black;
            this.Btn_Home.OnHoverImage = null;
            this.Btn_Home.OnPressedColor = System.Drawing.Color.Transparent;
            this.Btn_Home.Radius = 8;
            this.Btn_Home.Size = new System.Drawing.Size(160, 42);
            this.Btn_Home.TabIndex = 38;
            this.Btn_Home.Text = "Home";
            this.Btn_Home.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Btn_Home.Click += new System.EventHandler(this.Btn_Home_Click);
            // 
            // lblcampus
            // 
            this.lblcampus.AutoSize = true;
            this.lblcampus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcampus.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcampus.Location = new System.Drawing.Point(131, 657);
            this.lblcampus.Name = "lblcampus";
            this.lblcampus.Size = new System.Drawing.Size(95, 26);
            this.lblcampus.TabIndex = 18;
            this.lblcampus.Text = "Campus";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblsalary.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(131, 576);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(79, 26);
            this.lblsalary.TabIndex = 17;
            this.lblsalary.Text = "Salary";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfees.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfees.Location = new System.Drawing.Point(131, 493);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(58, 26);
            this.lblfees.TabIndex = 16;
            this.lblfees.Text = "Fees";
            this.lblfees.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblcourse
            // 
            this.lblcourse.AutoSize = true;
            this.lblcourse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblcourse.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourse.Location = new System.Drawing.Point(131, 415);
            this.lblcourse.Name = "lblcourse";
            this.lblcourse.Size = new System.Drawing.Size(85, 26);
            this.lblcourse.TabIndex = 15;
            this.lblcourse.Text = "Course";
            // 
            // lblfaculty
            // 
            this.lblfaculty.AutoSize = true;
            this.lblfaculty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblfaculty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfaculty.Location = new System.Drawing.Point(131, 335);
            this.lblfaculty.Name = "lblfaculty";
            this.lblfaculty.Size = new System.Drawing.Size(90, 26);
            this.lblfaculty.TabIndex = 14;
            this.lblfaculty.Text = "Faculty";
            // 
            // lblstudent
            // 
            this.lblstudent.AutoSize = true;
            this.lblstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblstudent.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudent.Location = new System.Drawing.Point(131, 180);
            this.lblstudent.Name = "lblstudent";
            this.lblstudent.Size = new System.Drawing.Size(91, 26);
            this.lblstudent.TabIndex = 12;
            this.lblstudent.Text = "Student";
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Image = global::University_Management_System.Properties.Resources.logout;
            this.gunaPictureBox10.Location = new System.Drawing.Point(44, 723);
            this.gunaPictureBox10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 9;
            this.gunaPictureBox10.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::University_Management_System.Properties.Resources.campus;
            this.gunaPictureBox9.Location = new System.Drawing.Point(44, 642);
            this.gunaPictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 8;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::University_Management_System.Properties.Resources.salary;
            this.gunaPictureBox8.Location = new System.Drawing.Point(44, 567);
            this.gunaPictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 7;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::University_Management_System.Properties.Resources.fees;
            this.gunaPictureBox7.Location = new System.Drawing.Point(44, 484);
            this.gunaPictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 6;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::University_Management_System.Properties.Resources.course;
            this.gunaPictureBox6.Location = new System.Drawing.Point(44, 406);
            this.gunaPictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 5;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::University_Management_System.Properties.Resources.faculty;
            this.gunaPictureBox5.Location = new System.Drawing.Point(44, 323);
            this.gunaPictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::University_Management_System.Properties.Resources.Department;
            this.gunaPictureBox4.Location = new System.Drawing.Point(44, 247);
            this.gunaPictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::University_Management_System.Properties.Resources.student;
            this.gunaPictureBox3.Location = new System.Drawing.Point(44, 170);
            this.gunaPictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::University_Management_System.Properties.Resources.home;
            this.gunaPictureBox2.Location = new System.Drawing.Point(44, 98);
            this.gunaPictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::University_Management_System.Properties.Resources.university;
            this.gunaPictureBox1.Location = new System.Drawing.Point(123, 13);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(73, 60);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.White;
            this.gunaPanel2.Controls.Add(this.cmp_delete);
            this.gunaPanel2.Controls.Add(this.cmp_edit);
            this.gunaPanel2.Controls.Add(this.cmp_exit);
            this.gunaPanel2.Controls.Add(this.Camp_DGV);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.cmp_btn_save);
            this.gunaPanel2.Controls.Add(this.Camp_DateDt);
            this.gunaPanel2.Controls.Add(this.Dir_RankTb);
            this.gunaPanel2.Controls.Add(this.Camp_DirTb);
            this.gunaPanel2.Controls.Add(this.Camp_CityTb);
            this.gunaPanel2.Controls.Add(this.Camp_NameTb);
            this.gunaPanel2.Controls.Add(this.gunaLabel7);
            this.gunaPanel2.Controls.Add(this.gunaLabel5);
            this.gunaPanel2.Controls.Add(this.gunaLabel4);
            this.gunaPanel2.Controls.Add(this.gunaLabel3);
            this.gunaPanel2.Controls.Add(this.gunaLabel6);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Location = new System.Drawing.Point(307, -1);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(914, 792);
            this.gunaPanel2.TabIndex = 21;
            // 
            // cmp_exit
            // 
            this.cmp_exit.AnimationHoverSpeed = 0.07F;
            this.cmp_exit.AnimationSpeed = 0.03F;
            this.cmp_exit.BaseColor = System.Drawing.Color.Transparent;
            this.cmp_exit.BorderColor = System.Drawing.Color.Black;
            this.cmp_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmp_exit.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmp_exit.ForeColor = System.Drawing.Color.Red;
            this.cmp_exit.Image = null;
            this.cmp_exit.ImageSize = new System.Drawing.Size(20, 20);
            this.cmp_exit.Location = new System.Drawing.Point(859, 18);
            this.cmp_exit.Name = "cmp_exit";
            this.cmp_exit.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.cmp_exit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.cmp_exit.OnHoverForeColor = System.Drawing.Color.Red;
            this.cmp_exit.OnHoverImage = null;
            this.cmp_exit.OnPressedColor = System.Drawing.Color.Black;
            this.cmp_exit.Size = new System.Drawing.Size(45, 42);
            this.cmp_exit.TabIndex = 11;
            this.cmp_exit.Text = "X";
            this.cmp_exit.Click += new System.EventHandler(this.cmp_exit_Click);
            // 
            // Camp_DGV
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.Camp_DGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Camp_DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Camp_DGV.BackgroundColor = System.Drawing.Color.White;
            this.Camp_DGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Camp_DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Camp_DGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Camp_DGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Camp_DGV.ColumnHeadersHeight = 4;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Camp_DGV.DefaultCellStyle = dataGridViewCellStyle6;
            this.Camp_DGV.EnableHeadersVisualStyles = false;
            this.Camp_DGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Camp_DGV.Location = new System.Drawing.Point(6, 462);
            this.Camp_DGV.Margin = new System.Windows.Forms.Padding(4);
            this.Camp_DGV.Name = "Camp_DGV";
            this.Camp_DGV.RowHeadersVisible = false;
            this.Camp_DGV.RowHeadersWidth = 51;
            this.Camp_DGV.RowTemplate.Height = 24;
            this.Camp_DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Camp_DGV.Size = new System.Drawing.Size(904, 312);
            this.Camp_DGV.TabIndex = 54;
            this.Camp_DGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.Camp_DGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Camp_DGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Camp_DGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Camp_DGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Camp_DGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Camp_DGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Camp_DGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Camp_DGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Camp_DGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Camp_DGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Camp_DGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Camp_DGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Camp_DGV.ThemeStyle.HeaderStyle.Height = 4;
            this.Camp_DGV.ThemeStyle.ReadOnly = false;
            this.Camp_DGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Camp_DGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Camp_DGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Camp_DGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Camp_DGV.ThemeStyle.RowsStyle.Height = 24;
            this.Camp_DGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Camp_DGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Camp_DGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Camp_DGV_CellContentClick);
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPanel3.Location = new System.Drawing.Point(-5, 450);
            this.gunaPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(1041, 6);
            this.gunaPanel3.TabIndex = 53;
            // 
            // cmp_btn_save
            // 
            this.cmp_btn_save.AnimationHoverSpeed = 0.07F;
            this.cmp_btn_save.AnimationSpeed = 0.03F;
            this.cmp_btn_save.BackColor = System.Drawing.Color.Transparent;
            this.cmp_btn_save.BaseColor = System.Drawing.Color.Transparent;
            this.cmp_btn_save.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.cmp_btn_save.BorderSize = 2;
            this.cmp_btn_save.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmp_btn_save.ForeColor = System.Drawing.Color.Black;
            this.cmp_btn_save.Image = null;
            this.cmp_btn_save.ImageSize = new System.Drawing.Size(20, 20);
            this.cmp_btn_save.Location = new System.Drawing.Point(93, 386);
            this.cmp_btn_save.Margin = new System.Windows.Forms.Padding(4);
            this.cmp_btn_save.Name = "cmp_btn_save";
            this.cmp_btn_save.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.cmp_btn_save.OnHoverBorderColor = System.Drawing.Color.Black;
            this.cmp_btn_save.OnHoverForeColor = System.Drawing.Color.White;
            this.cmp_btn_save.OnHoverImage = null;
            this.cmp_btn_save.OnPressedColor = System.Drawing.Color.Black;
            this.cmp_btn_save.Radius = 8;
            this.cmp_btn_save.Size = new System.Drawing.Size(132, 53);
            this.cmp_btn_save.TabIndex = 50;
            this.cmp_btn_save.Text = "Save";
            this.cmp_btn_save.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cmp_btn_save.Click += new System.EventHandler(this.cmp_btn_save_Click);
            // 
            // Camp_DateDt
            // 
            this.Camp_DateDt.Location = new System.Drawing.Point(320, 311);
            this.Camp_DateDt.Margin = new System.Windows.Forms.Padding(4);
            this.Camp_DateDt.Name = "Camp_DateDt";
            this.Camp_DateDt.Size = new System.Drawing.Size(205, 22);
            this.Camp_DateDt.TabIndex = 49;
            this.Camp_DateDt.Value = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            // 
            // Dir_RankTb
            // 
            this.Dir_RankTb.BaseColor = System.Drawing.Color.White;
            this.Dir_RankTb.BorderColor = System.Drawing.Color.Silver;
            this.Dir_RankTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Dir_RankTb.FocusedBaseColor = System.Drawing.Color.White;
            this.Dir_RankTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Dir_RankTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.Dir_RankTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Dir_RankTb.Location = new System.Drawing.Point(55, 306);
            this.Dir_RankTb.Margin = new System.Windows.Forms.Padding(4);
            this.Dir_RankTb.Name = "Dir_RankTb";
            this.Dir_RankTb.PasswordChar = '\0';
            this.Dir_RankTb.Radius = 5;
            this.Dir_RankTb.Size = new System.Drawing.Size(205, 32);
            this.Dir_RankTb.TabIndex = 48;
            // 
            // Camp_DirTb
            // 
            this.Camp_DirTb.BaseColor = System.Drawing.Color.White;
            this.Camp_DirTb.BorderColor = System.Drawing.Color.Silver;
            this.Camp_DirTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Camp_DirTb.FocusedBaseColor = System.Drawing.Color.White;
            this.Camp_DirTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Camp_DirTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.Camp_DirTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Camp_DirTb.Location = new System.Drawing.Point(575, 190);
            this.Camp_DirTb.Margin = new System.Windows.Forms.Padding(4);
            this.Camp_DirTb.Name = "Camp_DirTb";
            this.Camp_DirTb.PasswordChar = '\0';
            this.Camp_DirTb.Radius = 5;
            this.Camp_DirTb.Size = new System.Drawing.Size(205, 32);
            this.Camp_DirTb.TabIndex = 47;
            // 
            // Camp_CityTb
            // 
            this.Camp_CityTb.BaseColor = System.Drawing.Color.White;
            this.Camp_CityTb.BorderColor = System.Drawing.Color.Silver;
            this.Camp_CityTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Camp_CityTb.FocusedBaseColor = System.Drawing.Color.White;
            this.Camp_CityTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Camp_CityTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.Camp_CityTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Camp_CityTb.Location = new System.Drawing.Point(308, 195);
            this.Camp_CityTb.Margin = new System.Windows.Forms.Padding(4);
            this.Camp_CityTb.Name = "Camp_CityTb";
            this.Camp_CityTb.PasswordChar = '\0';
            this.Camp_CityTb.Radius = 5;
            this.Camp_CityTb.Size = new System.Drawing.Size(205, 32);
            this.Camp_CityTb.TabIndex = 46;
            // 
            // Camp_NameTb
            // 
            this.Camp_NameTb.BaseColor = System.Drawing.Color.White;
            this.Camp_NameTb.BorderColor = System.Drawing.Color.Silver;
            this.Camp_NameTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Camp_NameTb.FocusedBaseColor = System.Drawing.Color.White;
            this.Camp_NameTb.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Camp_NameTb.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.Camp_NameTb.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Camp_NameTb.Location = new System.Drawing.Point(46, 195);
            this.Camp_NameTb.Margin = new System.Windows.Forms.Padding(4);
            this.Camp_NameTb.Name = "Camp_NameTb";
            this.Camp_NameTb.PasswordChar = '\0';
            this.Camp_NameTb.Radius = 5;
            this.Camp_NameTb.Size = new System.Drawing.Size(205, 32);
            this.Camp_NameTb.TabIndex = 45;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel7.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(48, 271);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(185, 28);
            this.gunaLabel7.TabIndex = 44;
            this.gunaLabel7.Text = "Director Rank";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel5.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(314, 270);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(128, 28);
            this.gunaLabel5.TabIndex = 43;
            this.gunaLabel5.Text = "Join Date";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel4.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(569, 155);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(194, 28);
            this.gunaLabel4.TabIndex = 42;
            this.gunaLabel4.Text = "Director Name";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel3.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(302, 155);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(63, 28);
            this.gunaLabel3.TabIndex = 41;
            this.gunaLabel3.Text = "City";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaLabel6.Font = new System.Drawing.Font("Lucida Fax", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(40, 155);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(193, 28);
            this.gunaLabel6.TabIndex = 40;
            this.gunaLabel6.Text = "Campus Name";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Viner Hand ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(253, 71);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(312, 45);
            this.gunaLabel2.TabIndex = 39;
            this.gunaLabel2.Text = "Discovering Knowledge";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(232, 18);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(343, 45);
            this.gunaLabel1.TabIndex = 38;
            this.gunaLabel1.Text = "RK UNIVERSITY";
            // 
            // cmp_edit
            // 
            this.cmp_edit.AnimationHoverSpeed = 0.07F;
            this.cmp_edit.AnimationSpeed = 0.03F;
            this.cmp_edit.BackColor = System.Drawing.Color.Transparent;
            this.cmp_edit.BaseColor = System.Drawing.Color.Transparent;
            this.cmp_edit.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.cmp_edit.BorderSize = 2;
            this.cmp_edit.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmp_edit.ForeColor = System.Drawing.Color.Black;
            this.cmp_edit.Image = null;
            this.cmp_edit.ImageSize = new System.Drawing.Size(20, 20);
            this.cmp_edit.Location = new System.Drawing.Point(310, 386);
            this.cmp_edit.Margin = new System.Windows.Forms.Padding(4);
            this.cmp_edit.Name = "cmp_edit";
            this.cmp_edit.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.cmp_edit.OnHoverBorderColor = System.Drawing.Color.Black;
            this.cmp_edit.OnHoverForeColor = System.Drawing.Color.White;
            this.cmp_edit.OnHoverImage = null;
            this.cmp_edit.OnPressedColor = System.Drawing.Color.Black;
            this.cmp_edit.Radius = 8;
            this.cmp_edit.Size = new System.Drawing.Size(132, 53);
            this.cmp_edit.TabIndex = 55;
            this.cmp_edit.Text = "Edit";
            this.cmp_edit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cmp_edit.Click += new System.EventHandler(this.cmp_edit_Click);
            // 
            // cmp_delete
            // 
            this.cmp_delete.AnimationHoverSpeed = 0.07F;
            this.cmp_delete.AnimationSpeed = 0.03F;
            this.cmp_delete.BackColor = System.Drawing.Color.Transparent;
            this.cmp_delete.BaseColor = System.Drawing.Color.Transparent;
            this.cmp_delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(230)))), ((int)(((byte)(193)))));
            this.cmp_delete.BorderSize = 2;
            this.cmp_delete.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmp_delete.ForeColor = System.Drawing.Color.Black;
            this.cmp_delete.Image = null;
            this.cmp_delete.ImageSize = new System.Drawing.Size(20, 20);
            this.cmp_delete.Location = new System.Drawing.Point(540, 386);
            this.cmp_delete.Margin = new System.Windows.Forms.Padding(4);
            this.cmp_delete.Name = "cmp_delete";
            this.cmp_delete.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.cmp_delete.OnHoverBorderColor = System.Drawing.Color.Black;
            this.cmp_delete.OnHoverForeColor = System.Drawing.Color.White;
            this.cmp_delete.OnHoverImage = null;
            this.cmp_delete.OnPressedColor = System.Drawing.Color.Black;
            this.cmp_delete.Radius = 8;
            this.cmp_delete.Size = new System.Drawing.Size(132, 53);
            this.cmp_delete.TabIndex = 56;
            this.cmp_delete.Text = "Delete";
            this.cmp_delete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cmp_delete.Click += new System.EventHandler(this.cmp_delete_Click);
            // 
            // Campus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1224, 787);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Campus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Campus";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Camp_DGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaLabel lblcampus;
        private Guna.UI.WinForms.GunaLabel lblsalary;
        private Guna.UI.WinForms.GunaLabel lblfees;
        private Guna.UI.WinForms.GunaLabel lblcourse;
        private Guna.UI.WinForms.GunaLabel lblfaculty;
        private Guna.UI.WinForms.GunaLabel lblstudent;
        private Guna.UI.WinForms.GunaButton btn_salary;
        private Guna.UI.WinForms.GunaButton btn_fees;
        private Guna.UI.WinForms.GunaButton btn_course;
        private Guna.UI.WinForms.GunaButton btn_faculty;
        private Guna.UI.WinForms.GunaButton btn_department;
        private Guna.UI.WinForms.GunaButton Btn_student;
        private Guna.UI.WinForms.GunaButton Btn_Home;
        private Guna.UI.WinForms.GunaButton btn_campus;
        private Guna.UI.WinForms.GunaButton btn_logout;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaButton cmp_exit;
        private Guna.UI.WinForms.GunaDataGridView Camp_DGV;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaButton cmp_btn_save;
        private System.Windows.Forms.DateTimePicker Camp_DateDt;
        private Guna.UI.WinForms.GunaTextBox Dir_RankTb;
        private Guna.UI.WinForms.GunaTextBox Camp_DirTb;
        private Guna.UI.WinForms.GunaTextBox Camp_CityTb;
        private Guna.UI.WinForms.GunaTextBox Camp_NameTb;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaButton cmp_delete;
        private Guna.UI.WinForms.GunaButton cmp_edit;
    }
}