﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace University_Management_System
{
    public partial class Faculty : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=University_Management;Integrated Security=True");
        SqlCommand cmd;
        public Faculty()
        {
            InitializeComponent();
            GetDeptId();
            Display();
        }
        private void GetDeptId()
        {
                con.Open();
                cmd = new SqlCommand("Select DeptId from Department_Tbl", con);
                SqlDataReader Reader = cmd.ExecuteReader();
                DataTable data = new DataTable();
                data.Columns.Add("DeptId", typeof(int));
                data.Load(Reader);
                F_DeptIdCb.ValueMember = "DeptId";
                F_DeptIdCb.DataSource = data;
                con.Close();
        }
        private void GetDeptName()
        {
            con.Open();
            string Query = "Select * from Department_Tbl where DeptId = " + F_DeptIdCb.SelectedValue.ToString() + " ";
            cmd = new SqlCommand(Query, con);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            foreach (DataRow dataRow in data.Rows)
            {
                F_DeptTb.Text = dataRow["Name"].ToString();
            }
            con.Close();
        }
        private void Display()
        {
            DataTable data = new DataTable();
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select * from Faculty_Tbl", con);
            adapter.Fill(data);
            Faculty_DGV.DataSource = data;
            con.Close();
        }
        private void Reset()
        {
            F_NameTb.Text = "";
            ExperienceTb.Text = "";
            F_AddressTb.Text = "";
            F_DeptTb.Text = "";
            F_DeptTb.Text = "";
            QualificationCb.SelectedIndex = 0;
            F_GenderCb.SelectedIndex = 0;
            F_DeptIdCb.SelectedIndex = 0;
        }
        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            this.Hide();
            m.Show();
        }

        private void Btn_student_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            this.Hide();
            s.Show();
        }

        private void btn_department_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            this.Hide();
            d.Show();
        }

        private void btn_faculty_Click(object sender, EventArgs e)
        {
            Faculty f = new Faculty();
            this.Hide();
            f.Show();
        }

        private void btn_course_Click(object sender, EventArgs e)
        {
            Course cs = new Course();
            this.Hide();
            cs.Show();
        }

        private void btn_fees_Click(object sender, EventArgs e)
        {
            Fees fee = new Fees();
            this.Hide();
            fee.Show();
        }

        private void btn_salary_Click(object sender, EventArgs e)
        {
            Salaries salary = new Salaries();
            this.Hide();
            salary.Show();
        }

        private void btn_campus_Click(object sender, EventArgs e)
        {
            Campus cm = new Campus();
            this.Hide();
            cm.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Hide();
            lg.Show();
        }
        private void faculty_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void faculty_save_Click(object sender, EventArgs e)
        {
            if (F_NameTb.Text == "" || ExperienceTb.Text == "" || F_AddressTb.Text == "" || QualificationCb.SelectedIndex == -1 || F_DeptTb.Text == "" || F_GenderCb.SelectedIndex == -1 || F_DeptIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                cmd = new SqlCommand("Insert into Faculty_Tbl(Name,DOB,Gender,Address,Qualification,Experience,DeptId,Department,Salary)values(@FN,@FDOB,@FGen,@FAdd,@FQ,@FE,@FDeptId,@FDept,@FSal)", con);
                cmd.Parameters.AddWithValue("@FN", F_NameTb.Text);
                cmd.Parameters.AddWithValue("@FDOB", F_DOBdt.Value.Date);
                cmd.Parameters.AddWithValue("@FGen", F_GenderCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@FAdd", F_AddressTb.Text);
                cmd.Parameters.AddWithValue("@FQ", QualificationCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@FE", ExperienceTb.Text);
                cmd.Parameters.AddWithValue("@FDeptId", F_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@FDept", F_DeptTb.Text);
                cmd.Parameters.AddWithValue("@FSal", F_SalaryTb.Text);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Faculty Added");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }
        int Key = 0;
        private void F_DeptIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDeptName();
        }

        private void Faculty_DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            F_NameTb.Text = Faculty_DGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            F_DOBdt.Text = Faculty_DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            F_GenderCb.SelectedItem = Faculty_DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            F_AddressTb.Text = Faculty_DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            QualificationCb.SelectedItem = Faculty_DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            ExperienceTb.Text = Faculty_DGV.Rows[e.RowIndex].Cells[6].Value.ToString();
            F_DeptIdCb.SelectedValue = Faculty_DGV.Rows[e.RowIndex].Cells[7].Value.ToString();
            F_DeptTb.Text = Faculty_DGV.Rows[e.RowIndex].Cells[8].Value.ToString();
            F_SalaryTb.Text = Faculty_DGV.Rows[e.RowIndex].Cells[9].Value.ToString();
            if (F_NameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = int.Parse(Faculty_DGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        private void faculty_edit_Click(object sender, EventArgs e)
        {
            if (F_NameTb.Text == "" || ExperienceTb.Text == "" || F_AddressTb.Text == "" || QualificationCb.SelectedIndex == -1 || F_DeptTb.Text == "" || F_GenderCb.SelectedIndex == -1 || F_DeptIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information...", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                cmd = new SqlCommand("Update Faculty_Tbl Set Name=@FN,DOB=@FDOB,Gender=@FGen,Address=@FAdd,Qualification=@FQ,Experience=@FE,DeptId=@FDeptId,Department=@FDept,Salary=@FSal where F_Id=@FKey", con);
                cmd.Parameters.AddWithValue("@FN", F_NameTb.Text);
                cmd.Parameters.AddWithValue("@FDOB", F_DOBdt.Value.Date);
                cmd.Parameters.AddWithValue("@FGen", F_GenderCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@FAdd", F_AddressTb.Text);
                cmd.Parameters.AddWithValue("@FQ", QualificationCb.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@FE", ExperienceTb.Text);
                cmd.Parameters.AddWithValue("@FDeptId", F_DeptIdCb.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@FDept", F_DeptTb.Text);
                cmd.Parameters.AddWithValue("@FSal", F_SalaryTb.Text); ;
                cmd.Parameters.AddWithValue("@FKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Faculty Updated");
                Db.ShowDialog();
                con.Close();
                Display();
                Reset();
            }
        }

        private void faculty_delete_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Select The Faculty...!!", "University Management System", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                con.Open();
                cmd = new SqlCommand("Delete from Faculty_Tbl where F_Id=@FKey", con);
                cmd.Parameters.AddWithValue("@FKey", Key);
                cmd.ExecuteNonQuery();
                DialogBox Db = new DialogBox("Faculty Deleted");
                Db.ShowDialog();
                con.Close();
                Display();
            }
        }
    }
}
